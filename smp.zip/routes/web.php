<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
;
Route::get('bantuan', function () {
    return view('front.zakat');
});
/*---------- FRONT --------------------*/
Route::get('/','HomeController@index2');
Route::get('about','FrontColtroller2@about');
Route::get('prestasi','FrontColtroller2@prestasi');
Route::get('contact','FrontColtroller2@contact');
Route::post('addcontact','FrontColtroller2@addcontact');
Route::get('berita','FrontColtroller2@news');
Route::get('Detail/{title}','FrontColtroller2@detail');
Route::get('suka/{id}','FrontColtroller2@suka');
Route::get('tdksuka/{id}','FrontColtroller2@tdksuka');
Route::post('addcoment','FrontColtroller2@addcoment');
Route::get('gallery','FrontColtroller2@gallery');
Route::get('Downloads','FrontColtroller2@download');
// Route::get('teachers','FrontColtroller2@teachers');
// Route::get('Detail/{id}','FrontColtroller2@detail');
// Route::get('events','FrontColtroller2@events');
// Route::post('addcoment','FrontColtroller2@addcoment');
// Route::post('addcoment2','FrontColtroller2@addcoment2');


Auth::routes();
//Route::group(['middleware'=>'Auth'],function(){
Route::group(['middleware' => ['auth']], function () {
	Route::get('/home', 'HomeController@index');
	Route::get('/profil', 'HomeController@profil');
	Route::post('profil/edit/{id}','HomeController@updateprofil');
	Route::post('profil/update/{id}','HomeController@updateprofil2');

	Route::resource('slide','SlideshowController');
	Route::get('slide/active/{id}', 'SlideshowController@active');;
	Route::get('slide/inactive/{id}', 'SlideshowController@inactive');
	Route::get('slide/active2/{id}', 'SlideshowController@active2');;
	Route::get('slide/inactive2/{id}', 'SlideshowController@inactive2');
	
	Route::resource('news','NewsController');
	Route::resource('position','PositionController');
	Route::resource('staff','StaffController');
	Route::resource('kelas','KelasController');
	Route::resource('DownloadFile','DownloadFileController');
	Route::get('DownloadFile/active/{id}','DownloadFileController@active');
	Route::get('DownloadFile/inactive/{id}','DownloadFileController@inactive');
	Route::resource('Contact','ContactController');
	//Route::resource('Comentnews','ComentnewsController');
	Route::get('Comentnews/{id}','ComentnewsController@index');

	Route::get('Students/{id}','StudentsController@index');
	Route::get('Studentsedit/{id}/edit','StudentsController@edit');
	Route::get('Students/create/{id}','StudentsController@create');
	Route::post('Students','StudentsController@store');
	Route::delete('Studentsdelete/{id}','StudentsController@destroy');
	Route::put('Studentsupdate/{id}','StudentsController@update');
	Route::resource('achievement','PrestasiController');
});

