<?php

namespace App\Http\Controllers;
use App\Models\Slideshow;
use Illuminate\Http\Request;
use Alert;
class SlideshowController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Slideshow::all();
        return view('admin.slideshow.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.slideshow.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $ext = $request->file('image')->getClientOriginalExtension();
        $image = "slideshow_".date('YmdHis').strtolower('.'.$ext);
        $dest = "images/slideshow/";
        $request->file('image')->move($dest,$image);
        $data['image'] = $dest.$image;
        $data = Slideshow::create($data);
        Alert::success('Data berhasil di tambah', 'Selamat!');
        return redirect('slide/create')->with('success', 'Data berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Slideshow::find($id);
        return view('admin.slideshow.edit',compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if($request->has('image')){
            $ext = $request->file('image')->getClientOriginalExtension();
            $image = "slideshow_".date('YmdHis').strtolower('.'.$ext);
            $dest = "images/slideshow/";
            $request->file('image')->move($dest,$image);
            $name_image = $dest.$image;

            Slideshow::where('id',$id)->update(array(
                'title' => $request->title,
                'description' => $request->description,
                'image' => $name_image
            ));
        }else{
            Slideshow::where('id',$id)->update(array(
                'title' => $request->title,
                'description' => $request->description
            ));
        }
        Alert::success('Data berhasil di ubah', 'Selamat!');
        return redirect('slide')->with('success', 'Data berhasil di ubah');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Slideshow::find($id)->delete();
        Alert::success('Data berhasil di hapus', 'Selamat!');
        return redirect('slide')->with('success', 'Data berhasil di hapus');
    }

    function active($id)
    {
        Slideshow::where('id',$id)->update(array(
            'status' => 0
        ));
        Alert::success('Data berhasil di non-aktifkan', 'Selamat!');
        return redirect('slide')->with('success', 'Data berhasil di non-aktifkan');
    }

    function inactive($id)
    {
        Slideshow::where('id',$id)->update(array(
            'status' => 1
        ));
        Alert::success('Data berhasil di tampilkan ', 'Selamat!');
        return redirect('slide')->with('success', 'Data berhasil di aktifkan');
    }

    function active2($id)
    {
        Slideshow::where('id',$id)->update(array(
            'tampil' => 0
        ));
        Alert::success('Data berhasil di non-aktifkan', 'Selamat!');
        return redirect('slide')->with('success', 'Data berhasil di non-aktifkan');
    }

    function inactive2($id)
    {
        Slideshow::where('id',$id)->update(array(
            'tampil' => 1
        ));
        Alert::success('Data berhasil di aktifkan', 'Selamat!');
        return redirect('slide')->with('success', 'Data berhasil di aktifkan');
    }
}
