<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Slideshow;
use App\Models\Students;
use App\Models\Kelas;
use Auth;
use App\User;
use App\Models\Staff;
use Alert;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $thn = date('Y');
        $nextthn = date('Y')+1;
        $lastthn = date('Y');
        if(date('m') >= '1' and date('m') <= '6' ){
            $thnajaran = $lastthn.'/'.$thn;
        }else{
            $thnajaran = $thn.'/'.$nextthn;
        }
        $kelas = Kelas::all();
        $VII = Students::where('kelas','like','VII%')->where('kelas','not like','VIII%')->where('thajaran',$thnajaran)->count();
        $VIIP = Students::where('kelas','like','VII%')->where('jk','P')->where('kelas','not like','VIII%')->where('thajaran',$thnajaran)->count();
        $VIIL = Students::where('kelas','like','VII%')->where('jk','L')->where('kelas','not like','VIII%')->where('thajaran',$thnajaran)->count();

        $VIII = Students::where('kelas','like','VIII%')->where('thajaran',$thnajaran)->count();
        $VIIIP = Students::where('kelas','like','VIII%')->where('jk','P')->where('thajaran',$thnajaran)->count();
        $VIIIL = Students::where('kelas','like','VIII%')->where('jk','L')->where('thajaran',$thnajaran)->count();

        $IX = Students::where('kelas','like','IX%')->where('thajaran',$thnajaran)->count();
        $IXP = Students::where('kelas','like','IX%')->where('jk','P')->where('thajaran',$thnajaran)->count();
        $IXL = Students::where('kelas','like','IX%')->where('jk','L')->where('thajaran',$thnajaran)->count();

        return view('admin.index',compact('VII','VIIP','VIIL','VIII','VIIIP','VIIIL','IX','IXP','IXL'));
    }

    public function index2()
    {
        $slide = Slideshow::all()->where('status','1');
        return view('front.index',compact('slide'));
    }

    public function profil()
    {
        $user = Auth::user();
        $staff = Staff::where('user_id',$user->id)->first();
        return view('admin.profil',compact('user','staff'));
    }

    public function updateprofil(Request $request)
    {
        $id = $request->id;
        $data = Staff::where('id',$id)->update(array(
                        'name' => $request->name,
                        'dob' => $request->dob,
                        'pob' => $request->pob,
                        'email' => $request->email,
                        'hp' => $request->hp,
                        'jk' => $request->jk
            ));
        if($data){
            $user = User::where('id',$request->user_id)->update(array(
                'name'=>$request->name,
                'email'=>$request->email
            ));
            Alert::success('Data Profil berhasil di ubah');
            return redirect('profil')->with('success', 'Data profil berhasil di ubah'); 
        }else{
            Alert::error('Data Profil gagal di ubah');
            return redirect('profil')->with('error', 'Data profil berhasil di ubah');  
        }  
    }   
    public function updateprofil2(Request $request)
    {
        $id = $request->id;
        // return $id;
        $this->validate($request, [
            'image' => 'mimes:jpg,jpeg,png|required',
        ]);
        $ext = $request->file('image')->getClientOriginalExtension();
        $image = "staff_".$request->input('name').'_'.date("YmdHis").strtolower('.'.$ext);
        $destination  = 'images/staff/';
        $request->file('image')->move($destination,$image);
        $image_name=$destination.$image;
        $data2 = Staff::where('id',$id)->update(array(
            'foto' => $image_name
        ));
        if($data2){
            Alert::success('Foto Profil berhasil di ubah');
            return redirect('profil')->with('success2', 'Foto profil berhasil di ubah'); 
        }else{
            Alert::error('Foto Profil gagal di ubah');
            return redirect('profil')->with('error2', 'Foto profil berhasil di ubah');  
        }  
    }
}
