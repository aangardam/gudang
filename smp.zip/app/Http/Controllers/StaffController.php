<?php

namespace App\Http\Controllers;
use App\Models\Staff;
use App\Models\Position;
use Illuminate\Http\Request;
use Alert;
use Mail;
use App\User;
class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Staff::all()->where('user_id','!=',1);
        return view('admin.staff.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = Position::all()->where('id','!=',1);
        return view('admin.staff.create',compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $pass = '12341234';
        $user = User::create([
            'name'      => $request->name,
            'email'     => $request->email,
            'password'  => bcrypt('12341234')
        ]);
        $user->attachRole(2);
        if ($user) {
            $data['user_id']= $user->id;
            if($request->file('image')){
                $ext = $request->file('image')->getClientOriginalExtension();
                $image = "staff_".$request->input('name').'_'.date("YmdHis").strtolower('.'.$ext);
                $dest = "images/staff/";
                $request->file('image')->move($dest,$image);
                $data['foto'] = $dest.$image;
                
            }
            $data = staff::create($data);
            Mail::send('admin.mail.mailuser', compact('user','pass'), function ($m) use($user) {
                $m->to($user->email)->subject('akun anda');
            });
            Alert::success('Data berhasil di tambah', 'Selamat!');
            return redirect('staff/create')->with('success', 'Data berhasil di tambah');   
        }else{
            Alert::error('Data gagal di tambah', 'Maaf!');
            return redirect('staff/create')->with('error', 'Data gagal di tambah');   
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Staff::find($id);
        $jabatan = Position::all()->where('id','!=',1);
        return view('admin.staff.edit',compact('data','jabatan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if($request->has('image')){
            $ext = $request->file('image')->getClientOriginalExtension();
            $image = "staff_".$request->input('name').'_'.date("YmdHis").strtolower('.'.$ext);
            $dest = "images/staff/";
            $request->file('image')->move($dest,$image);
            $name_image = $dest.$image;

            Staff::where('id',$id)->update(array(
                'name' => $request->name,
                'nip' => $request->nip,
                'foto' => $name_image,
                'dob' => $request->dob,
                'pob' => $request->pob,
                'email' => $request->email,
                'hp' => $request->hp,
                'jk' => $request->jk,
                'pendidikan' => $request->pendidikan,
                'school' => $request->school,
                'position_id' => $request->position_id,
                'nuptk' => $request->nuptk
                
            ));
        }else{
            Staff::where('id',$id)->update(array(
                'name' => $request->name,
                'nip' => $request->nip,
                'dob' => $request->dob,
                'pob' => $request->pob,
                'email' => $request->email,
                'hp' => $request->hp,
                'jk' => $request->jk,
                'pendidikan' => $request->pendidikan,
                'school' => $request->school,
                'position_id' => $request->position_id,
                'nuptk' => $request->nuptk
            ));
        }
        Alert::success('Data berhasil di ubah', 'Selamat!');
        return redirect('staff')->with('success', 'Data berhasil di ubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $staff = Staff::where('id',$id)->first();
        $user = User::where('id', $staff->user_id)->delete();
        // $data = Staff::find($id)->delete();
        Alert::success('Data berhasil di hapus', 'Selamat!');
        return redirect('staff')->with('success', 'Data berhasil di hapus');
    }
}
