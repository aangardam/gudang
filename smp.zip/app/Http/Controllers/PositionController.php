<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Position;
use App\Role;
use Alert;
class PositionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Position::all()->where('id','!=',1);
        return view('admin.position.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.position.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $data = Position::create($data);
        $postion = Position::select('id')->orderBy('id','desc')->first();
        // return $postion->id;
        if ($data) {
            $role = Role::create([
                'id' => $postion->id,
                'name'      => $request->code,
                'display_name'     => $request->name
            ]);
        }
        Alert::success('Data berhasil di tambah', 'Selamat!');
        return redirect('position/create')->with('success', 'Data berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Position::find($id);
        return view('admin.position.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //return $request->all();
        Position::where('id',$id)->update(array(
            'code'=>$request->code,
            'name'=>$request->name
        ));
        Role::where('id',$id)->update(array(
            'name'      => $request->code,
            'display_name'     => $request->name
        ));
        Alert::success('Data berhasil di ubah', 'Selamat!');
        return redirect('position')->with('success', 'Data berhasil di ubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Position::find($id)->delete();
        $role = Role::find($id)->delete();
        Alert::success('Data berhasil di hapus', 'Selamat!');
        return redirect('position')->with('success', 'Data berhasil di hapus');
    }
}
