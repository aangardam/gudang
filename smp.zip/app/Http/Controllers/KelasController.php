<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kelas;
use App\Models\Staff;
use Alert;
class KelasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Kelas::all();
        return view('admin.kelas.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = Staff::select('id','name')->get();
        return view('admin.kelas.create',compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $data = Kelas::create($data);
        Alert::success('Data berhasil di tambah', 'Selamat!');
        return redirect('kelas/create')->with('success', 'Data berhasil di tambah');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Kelas::find($id);
        $wali = Staff::select('id','name')->get();
        return view('admin.kelas.edit',compact('data','wali'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        Kelas::where('id',$id)->update(array(
            'name' => $request->name,
            'alamat' => $request->alamat,
            'staff_id' => $request->staff_id
        ));
        Alert::success('Data berhasil di ubah', 'Selamat!');
        return redirect('kelas')->with('success', 'Data berhasil di ubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Kelas::find($id)->delete();
        Alert::success('Data berhasil di hapus', 'Selamat!');
        return redirect('kelas')->with('success', 'Data berhasil di hapus');
    }
}
