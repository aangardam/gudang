<?php

namespace App\Http\Controllers;
use App\Models\DownloadFile;
use Illuminate\Http\Request;
use Alert;
class DownloadFileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DownloadFile::all();
        return view('admin.DownloadFile.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.DownloadFile.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $ext = $request->file('filename')->getClientOriginalExtension();
        $filename = "DownloadFile".date('YmdHis').strtolower('.'.$ext);
        $dest = "filename/downloadfile/";
        $request->file('filename')->move($dest,$filename);
        $data['filename'] = $dest.$filename;
        $data = DownloadFile::create($data);
        Alert::success('Data berhasil di tambah', 'Selamat!');
        return redirect('DownloadFile/create')->with('success', 'Data berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data =DownloadFile::find($id);
        return view('admin.DownloadFile.edit',compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if($request->has('filename')){
            $ext = $request->file('filename')->getClientOriginalExtension();
            $filename = "DownloadFile".date('YmdHis').strtolower('.'.$ext);
            $dest = "filename/downloadfile/";
            $request->file('filename')->move($dest,$filename);
            $file_name = $dest.$filename;
            DownloadFile::where('id',$id)->update(array(
                'title'=>$request->title,
                'filename'=>$file_name
            ));
        } else {
            DownloadFile::where('id',$id)->update(array(
                'title'=>$request->title
            ));
        }
        
        Alert::success('Data berhasil di ubah','Selamat!');
        return redirect('DownloadFile')->with('success','Data berhasil di ubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = DownloadFile::find($id)->delete();
        Alert::success('Data berhasil di hapus', 'Selamat!');
        return redirect('DownloadFile')->with('success', 'Data berhasil di hapus');
    }
    function active($id)
    {
        DownloadFile::where('id',$id)->update(array(
            'status' => 0
        ));
        Alert::success('Data berhasil di non-aktifkan', 'Selamat!');
        return redirect('DownloadFile')->with('success', 'Data berhasil di non-aktifkan');
    }

    function inactive($id)
    {
        DownloadFile::where('id',$id)->update(array(
            'status' => 1
        ));
        Alert::success('Data berhasil di tampilkan ', 'Selamat!');
        return redirect('DownloadFile')->with('success', 'Data berhasil di aktifkan');
    }
}
