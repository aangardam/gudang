<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\News;
use Alert;
class NewsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = News::all();
        return view('admin.news.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.news.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $ext = $request->file('image')->getClientOriginalExtension();
        $image = "news".date('YmdHis').strtolower('.'.$ext);
        $dest = "images/news/";
        $request->file('image')->move($dest,$image);
        $data['image'] = $dest.$image;
        $data = News::create($data);
        Alert::success('Data berhasil di tambah', 'Selamat!');
        return redirect('news/create')->with('success', 'Data berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = News::find($id);
        return view('admin.news.edit',compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if($request->has('image')){
            $ext = $request->file('image')->getClientOriginalExtension();
            $image = "news".date('YmdHis').strtolower('.'.$ext);
            $dest = "images/news/";
            $request->file('image')->move($dest,$image);
            $name_image = $dest.$image;

            News::where('id',$id)->update(array(
                'title' => $request->title,
                'isi' => $request->isi,
                'image' => $name_image
            ));
        }else{
            News::where('id',$id)->update(array(
                'title' => $request->title,
                'isi' => $request->isi
            ));
        }
        Alert::success('Data berhasil di ubah', 'Selamat!');
        return redirect('news')->with('success', 'Data berhasil di ubah');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = News::find($id)->delete();
        Alert::success('Data berhasil di hapus', 'Selamat!');
        return redirect('news')->with('success', 'Data berhasil di hapus');
    }
}
