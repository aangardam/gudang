<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DownloadFile;
use App\Models\Contact;
use Alert;
use App\Models\News;
Use App\Models\ComentNews;
use App\Models\Slideshow;
use App\Models\Prestasi;
class FrontColtroller2 extends Controller
{
    public function about()
    {
       
        return view('front.about');
    }

    public function teachers()
    {
        
        // $Guru = Guru::all()->where('jabatan','!=','TU');
        // return view('front.guru',compact('Guru'));
    }

    public function contact()
    {
       
        return view('front.kontak');
    }
    public function news()
    {
       
        $berita = News::all();
        return view('front.berita',compact('berita'));
    }

    public function detail($title)
    {
        $title2 = str_replace('-',' ',$title);
        $berita = News::where('title',$title2)->first();
        $baca = $berita->read;
        News::where('title',$title2)->update(array(
            'read' => $baca +1
        ));
        $coment = ComentNews::where('berita_id',$berita->id)->get();
        //return $coment;
        //return $baca;
        //$comment = comment::all()->where('berita_id','==',$id);
        return view('front.detail',compact('berita','coment'));
    }


    public function events()
    {
        
        // $event = event::all();
        // return view('front.kegiatan',compact('event'));
    }

    public function detail2($id)
    {
        
        // $event = event::find($id);
        // $comment2 = comment2::all()->where('evnets_id','==',$id);
        // return view('front.detail2',compact('event','comment2'));
    }

    public function gallery()
    {
       
        // $album = album::all();
        // $galery = galery::all();
        $galery = Slideshow::all()->where('tampil','1');
        return view('front.foto',compact('galery'));
    }
    public function addcontact(Request $request)
    {
        $data = $request->all();
        //$email = $request->input('email');
        $Contacts = Contact::create($data);
        return redirect('contact');
       
    }
    public function addcoment(Request $request)
    {
        $data = $request->all();
        //return $data;
        $id = $data['berita_id'];
        $judul = News::where('id',$id)->first();
        $judul = str_replace(' ','-',$judul->title);
        $comment = ComentNews::create($data);
        return redirect('Detail/'.$judul)->with([
            'berita' => $data
        ]);
    }

    public function addcoment2(Request $request)
    {
        // $data = $request->all();
        // $comment2 = comment2::create($data);
        // return redirect('contact');
    }

    public function download()
    {
        $download = DownloadFile::all()->where('status','==','1');
        return view('front.download',compact('download'));

    }

    public function suka($id)
    {
        $data = News::where('id',$id)->first();
        $suka = $data->suka+1;
        $judul = $data->title;
        $judul = str_replace(' ','-',$data->title);
        News::where('id',$id)->update(array(
            'suka' => $suka
        ));
        return redirect('Detail/'.$judul)->with([
            'berita' => $data
        ]);
    }
    public function tdksuka($id)
    {
        $data = News::where('id',$id)->first();
        $suka = $data->tdksuka+1;
        $judul = $data->title;
        $judul = str_replace(' ','-',$data->title);
        News::where('id',$id)->update(array(
            'tdksuka' => $suka
        ));
        return redirect('Detail/'.$judul)->with([
            'berita' => $data
        ]);
    }

    public function prestasi(){
        $data = Prestasi::all();
        return view('front.prestasi',compact('data'));
    }
}