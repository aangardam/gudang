<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Kelas extends Model
{
    use SoftDeletes;
    protected $fillable=['name','alamat','staff_id'];

    public function wali()
    {
        return $this->belongsTo('App\Models\Staff','staff_id');
    }

    protected $dates = ['deleted_at'];
}
