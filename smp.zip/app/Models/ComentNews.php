<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ComentNews extends Model
{
    protected $fillable=['id','berita_id','name','email','hp','isi'];

    public function berita()
    {
        return $this->belongsTo('App\Models\News','berita_id');
    }
}
