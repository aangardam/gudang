<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Prestasi extends Model
{
    use SoftDeletes;
    protected $fillable=['title','keterangan','image','tanggal'];

    protected $dates = ['deleted_at'];
}
