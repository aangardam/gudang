<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Staff extends Model
{
    use SoftDeletes;
    protected $fillable =['id','nip','name','dob','pob','email','hp','jk','foto','pendidikan','school','position_id','nuptk','user_id'];

    public function jabatan()
    {
        return $this->belongsTo('App\Models\Position','position_id');
    }

    protected $dates = ['deleted_at'];
}
