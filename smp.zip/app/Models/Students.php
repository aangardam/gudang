<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Students extends Model
{
    use SoftDeletes;
    protected $fillable =['id','nis','name','dob','pob','email','hp','jk','foto','pendidikan','school','kelas_id','thajaran','kelas'];

    public function kelas()
    {
        return $this->belongsTo('App\Models\Kelas','kelas_id');
    }

    protected $dates = ['deleted_at'];
}
