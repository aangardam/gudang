<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateComentNewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('coment_news', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('berita_id')->unsigned();
            $table->string('name');
            $table->string('email')->nullable();
            $table->string('hp')->nullable();
            $table->text('isi');
            $table->timestamps();


        $table->foreign('berita_id')->references('id')->on('news')
             ->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('coment_news');
    }
}
