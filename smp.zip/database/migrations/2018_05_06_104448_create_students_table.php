<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->increments('id');
            $table->string('nis')->default('-');
            $table->string('name');
            $table->string('dob')->nullable();
            $table->string('pob')->nullable();
            $table->string('email')->nullable();
            $table->string('hp')->nullable();
            $table->enum('jk',['L','P']);
            $table->string('foto')->nullable();
            $table->string('thajaran');
            $table->string('kelas')->nullable();
            $table->integer('kelas_id')->unsigned();
            $table->foreign('kelas_id')->references('id')->on('kelas')->onDelete('cascade')->onUpdate('cascade');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}
