<?php

use Illuminate\Database\Seeder;
use App\Models\Position;
class PositionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $position = [
            [
                'code' => 'Admin',
                'name' => 'Administator',
                'created_at' => now()
            ],
            [
                'code' => 'Guru',
                'name' => 'Guru',
                'created_at' => now(),
            ],
            
        ];
        foreach ($position as $key => $value) {
            $position = Position::create($value);
        }
    }
}
