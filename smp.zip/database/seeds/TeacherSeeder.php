<?php

use Illuminate\Database\Seeder;
use App\Models\Staff;

class TeacherSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $Staff = [
            [
                'nip' => '1234',
                'nuptk' => '4321',
                'name' => 'Admin',
                'dob' => '2000-01-01',
                'pob' => '-',
                'email' => 'admin@smpit.com',
                'hp' => '-',
                'jk' => 'L',
                'pendidikan' => 'S1',
                'school' => '-',
                'position_id' => '1',
                'user_id' => '1',
            ],
            
        ];
        foreach ($Staff as $key => $value) {
            $Staff = Staff::create($value);
        }
    }
}
