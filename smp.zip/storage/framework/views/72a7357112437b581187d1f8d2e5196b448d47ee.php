<?php $__env->startSection('content'); ?>
<div class="banner">
</div>
<!-- //banner -->
<div class="about w3agile-1">
	<div class="container">
		<h1 class="title">Tentang Kami</h1>
		<div class="about-info">
			<div class="col-md-7 about-grids">
				<div class="about-row">
					<!-- <div class="col-md-4 about-imgs">
						<img src="<?php echo e(asset('front/images/1.jpg')); ?>" alt="" class="img-responsive zoom-img"/>
					</div>
					<div class="col-md-4 about-imgs">
						<img src="<?php echo e(asset('front/images/2.jpg')); ?>" alt=""  class="img-responsive zoom-img"/>
					</div>
					<div class="col-md-4 about-imgs">
						<img src="<?php echo e(asset('front/images/3.jpg')); ?>" alt=""  class="img-responsive zoom-img"/>
					</div> -->
					<div class="clearfix"> </div>
				</div>
				<h4><b> Identitas SMP IT Darurrohmat </b></h4>
				<p>
					<b>Nama Lembaga                 </b>         : SMP IT Darurrohmat <br>
					<b>Jenis Pendidikan         </b>              : Islam Terpadu (IT) <br>
					<b>Lembaga Penyelenggara</b>          : Yayasan Darurrohmat Assakhi <br>
					<b>Alamat Lembaga </b>                       : Kampung sugih RT 04 RW 07 blok Jum'at
					Desa Parakan Kecamatan Leuwimunding Kabupaten Majalengka
					Desa Parakan Kecamatan Leuwimunding Kabupaten Majalengka
					Kode Pos                                    : 45473 <br>
					<b>Nomor HP Lembaga</b>                               : 081220933003 / 08132435329 <br>
					<b>Email Lembaga</b>                          : smpit.darurrohmat@gmail.com </p>	

				<h4><b> Tujuan SMP IT Darurrohmat </b></h4>
				<p>Mengembangkan segenap potensi civitas akademik SMP IT Darurrohmat yang bertakwa, beriman, berilmu, beramal, dan berakhlak mulia serta kreatif, mandiri dan bertanggung jawab.</p>		
				</div>
				<div class="col-md-5 about-grids">
					<div class="pince">
						<div class="pince-left">
							<span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>
						</div>
						<div class="pince-right">
							<h4> Visi </h4>
							<p>Terwujudnya lembaga pendidikan islam yang melahirkan generasi berilmu, beramal, dan berakhlakul karimah..</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="pince">
						<div class="pince-left">
							<span class="glyphicon glyphicon-tasks" aria-hidden="true"></span>
						</div>
						<div class="pince-right">
							<h4>Misi</h4>
							<p>
								1. Melakukan Transformasi ilmu pengetahuan dan menanamkan nilai-nilai islam.<br>
								2. Menyelenggarakan pendidikan guna menghasilkan insan yang beriman, berilmu dan berakhlakul karimah.<br>
								3. Menyelenggarakan pendidikan yang berkualitas dalam pencapaian prestasi akademik dan non akademik guna menghasilkan lulusan yang mandiri dan memiliki kemampuan yang kompetitif.<br>
								4. Mengembangkan kreatifitas budaya belajar yang maju dan mandiri sesuai tuntutan ilmu pengetahuan dan teknologi guna tercapainya tujuan pendidikan nasional.<br>
							</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<!-- <div class="pince">
						<div class="pince-left">
							<span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>
						</div>
						<div class="pince-right">
							<h4>Tujuan</h4>
							<p>Mengembangkan segenap potensi civitas akademik SMP IT Darurrohmat yang bertakwa, beriman, berilmu, beramal, dan berakhlak mulia serta kreatif, mandiri dan bertanggung jawab.</p>
						</div>
						<div class="clearfix"> </div>
					</div> -->
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>