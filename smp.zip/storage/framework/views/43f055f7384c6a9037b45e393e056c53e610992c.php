<?php $__env->startSection('title'); ?>
| Staff
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
  window.remove = function (id) {
      event.preventDefault();
  
      swal({
          title: "Apakah Anda Yakin?",
          text: "Staff yang sudah di hapus tidak dapat di kembalikan!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Ya, Hapus!",
          cancelButtonText: 'Batal',
          closeOnConfirm: false,
          html: false
      }, function () {
          document.getElementById('delete-' + id).submit();
          swal("Berhasil!",
              "Staff sudah dihapus.",
              "success");
      });
  };
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-users"></i> Staff</h1>
      
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Staff</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div align="right">
            <a href="<?php echo e(url ('staff/create')); ?>" class="btn btn-primary btn-sm">
                <b><i class="fa fa-plus"></i></b> Staff
            </a>
        </div>
        <hr>
        <table class="table table-hover table-bordered" id="sampleTable">
            <thead>
                <tr>
                    <td><b> No </b></td>
                    <td><b> NUPTK </b></td>
                    <td><b> NIP </b></td>
                    <td><b> Nama </b></td>
                    <td><b> Jabatan </b></td>
                    <td><b> E-mail </b></td>
                    <td><b> No Telp </b></td>
                    <td><b> Foto </b></td>
                    <td><b> Update </b></td>
                </tr>
            </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($item+1); ?></td>
                    <td> <?php echo e($value->nuptk); ?> </td>
                    <td> <?php echo e($value->nip); ?> </td>
                    <td> <?php echo e($value->name); ?> </td>
                    <td> <?php echo e($value->jabatan->name); ?> </td>
                    <td> <?php echo e($value->email); ?> </td>
                    <td> <?php echo e($value->hp); ?> </td>
                    <td>
                        <img src="<?php echo e($value->foto); ?>" width="50px">
                    </td>
                    <td>
                        <form id="delete-<?php echo e($value->id); ?>"
                          action="<?php echo e(action('StaffController@destroy', ['id' => $value->id])); ?>" method="POST"
                          style="display: none;">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('DELETE')); ?>

                        </form>
                        <a class="btn btn-danger btn-xs" style="padding: 0px 5px 0px 5px;color: #fff"
                          onclick="remove(<?php echo e($value->id); ?>)">
                          Hapus
                        </a>
                        <a href=" <?php echo e(url('staff/'.$value->id.'/edit')); ?> " class="btn btn-primary btn-xs" style="padding: 0px 5px 0px 5px"> Ubah </a>
                      </td>
                     
                    </tr>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>        	
        </table>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>