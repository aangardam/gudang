Hai, <b><?php echo e($user->name); ?></b><hr>
Selamat akun anda telah terdaftar, silahkan login
