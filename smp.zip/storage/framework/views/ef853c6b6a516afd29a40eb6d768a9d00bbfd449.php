<?php $__env->startSection('content'); ?>
<div class="banner">
</div>
<!-- //banner -->
<div class="contact agileinfo">
	<div class="container">
	<h1 class="title">Kontak</h1>
		<div class="contact-top">
			<div class="col-md-6 col-sm-6 cl  agileinfo-1">
				<h4>Kontak Kami</h4>
				<form action="<?php echo e(url('addcontact')); ?>" method="post">
				 <?php echo e(csrf_field()); ?>

					<input type="text" name="name" placeholder="Nama" required=""><br>
					<input type="text" name="email" placeholder="EMAIL"><br>
					<input type="text" name="telp" placeholder="No HP"><br>
					<textarea rows="4" cols="50" name="isi" placeholder="Pesan" required></textarea><br>
					<p><i><font color="red"> No Telp atau Email harap di isi, untuk memberikan feedback ke anda </font></i></p>
					<input type="submit" class="hvr-rectangle-in" value="Kirim">
				</form>
			</div>
			<div class="col-md-6 col-sm-6 cr  agileinfo-2">
				<h4>Alamat Kami:</h4>
				<h5>Kampung sugih RT 04 RW 07 blok Jumat Desa Parakan,   <br>Leuwimunding, <br>Majalengka.</h5>
				<h4> Phone:</h4>
				<h5>081220933003 / 08132435329</h5>
				<h4>E-mail:</h4>
				<h5><a href="mailto:smpit.darurrohmat@gmail.com">smpit.darurrohmat@gmail.com</a></h5>
				<h4>Our Website:</h4>
				<h5><a href="smpit-darurrohmat.sch.id/">http://smpit-darurrohmat.sch.id.com</a></h5>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- <h2 class="title">View On Map</h2>
<div class="map  agileinfo-3">
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13251.379579532895!2d151.20123713732173!3d-33.867887973599956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12ae401e8b983f%3A0x5017d681632ccc0!2sSydney+NSW+2000%2C+Australia!5e0!3m2!1sen!2sin!4v1471840520875" style="border:0" allowfullscreen></iframe>
</div> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>