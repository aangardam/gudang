<?php $__env->startSection('title'); ?>
| Staff
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-picture-o"></i> Staff</h1>
      
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Staff</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Edit Staff</h5>
        <hr>
        <form class="forms-sample" action="<?php echo e(url('staff/'.$data->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e($data->id); ?>" />
			<input type="hidden" name="_method" value="put">
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> NIP </label>
                </div>
                <div class="col-4">
                    <input type="text" name="nip" id="name" class="form-control" required="" value="<?php echo e($data->nip); ?>">
                </div>
            
                <div class="col-2">
                    <label><small class="text-danger">*</small> NUPTK </label>
                </div>
                <div class="col-4">
                    <input type="text" name="nuptk" id="nuptk" class="form-control" required="" value="<?php echo e($data->nuptk); ?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> Nama </label>
                </div>
                <div class="col-4">
                    <input type="text" name="name" id="name" class="form-control" required="" value="<?php echo e($data->name); ?>">
                </div>

                <div class="col-2">
                    <label><small class="text-danger">*</small> Jabatan </label>
                </div>
                <div class="col-4">
                    <select name="position_id" id="material_type_id" required="" class="form-control">
                        <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($value2->id == $data->position_id): ?>
                                <option value="<?php echo e($value2->id); ?>" selected> <?php echo e($value2->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($value2->id); ?>"> <?php echo e($value2->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> JK </label>
                </div>
                <div class="col-4">
                    <select class="form-control" name="jk">
                        <?php if($data->jk=='L'): ?>
                            <option value="L"> Laki - Laki </option>
                            <option value="P"> Perempuan </option>
                        <?php else: ?>
                            <option value="P"> Perempuan </option>
                            <option value="L"> Laki - Laki </option>
                        <?php endif; ?>
                       
                    </select>
                </div>
                <div class="col-2">
                    <label> Foto </label>
                </div>
                <div class="col-4">
                    <input type="file" name="image" id="pob" class="form-control" >
                </div>
            </div>

            <div class="form-group row">
                <div class="col-2">
                    <label> Tempat Lahir </label>
                </div>
                
                <div class="col-4">
                    <input type="text" name="pob" id="pob" class="form-control" value="<?php echo e($data->pob); ?>">
                </div>
                <div class="col-2">
                    <label> Tanggal Lahir </label>
                </div>
                <div class="col-4">
                    <input type="text" name="dob" class="form-control datepicker" value="<?php echo e($data->dob); ?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-2">
                    <label> E-Mail </label>
                </div>
                <div class="col-4">
                    <input type="text" name="email" id="email" class="form-control" value="<?php echo e($data->email); ?>">
                </div>

                <div class="col-2">
                    <label> No HP </label>
                </div>
                <div class="col-4">
                    <input type="text" name="hp" id="hp" class="form-control" value="<?php echo e($data->hp); ?>">
                </div>
            </div>

            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> Pendidikan </label>
                </div>
                <div class="col-4">
                    <select name="pendidikan" class="form-control">
                        <?php if($data->pendidikan=='SMA'): ?>
                            <option> SMA </option>
                            <option> D3 </option>
                            <option> S1 </option>
                            <option> S2 </option>
                        <?php elseif($data->pendidikan=='D3'): ?>
                            <option> D3 </option>
                            <option> SMA </option>
                            <option> S1 </option>
                            <option> S2 </option>
                        <?php elseif($data->pendidikan=='D1'): ?>
                            <option> S1 </option>
                            <option> SMA </option>
                            <option> D3 </option>
                            <option> S2 </option>
                        <?php else: ?>
                            <option> S2 </option>
                            <option> SMA </option>
                            <option> D3 </option>
                            <option> S1 </option>                           
                        <?php endif; ?>
                        
                    </select>
                </div>

                <div class="col-2">
                    <label> Lulusan </label>
                </div>
                <div class="col-4">
                    <input type="text" name="school" id="hp" class="form-control" value="<?php echo e($data->school); ?>">
                </div>
            </div>
            
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="<?php echo e(url('staff')); ?>" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>