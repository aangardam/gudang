<?php $__env->startSection('title'); ?>
| Position
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
  window.remove = function (id) {
      event.preventDefault();
  
      swal({
          title: "Apakah Anda Yakin?",
          text: "Position yang sudah di hapus tidak dapat di kembalikan!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Ya, Hapus!",
          cancelButtonText: 'Batal',
          closeOnConfirm: false,
          html: false
      }, function () {
          document.getElementById('delete-' + id).submit();
          swal("Berhasil!",
              "Position sudah dihapus.",
              "success");
      });
  };
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-picture-o"></i> Position</h1>
      
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Position</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div align="right">
            <a href="<?php echo e(url ('position/create')); ?>" class="btn btn-primary btn-sm">
                <b><i class="fa fa-plus"></i></b> Position
            </a>
        </div>
        <hr>
        <table class="table table-hover table-bordered" id="sampleTable">
            <thead>
                <tr>
                  <td><b> No </b></td>
                  <td><b> Kode </b></td>
                  <td><b> Jabatan </b></td>
                  
                  <td><b>  </b></td>
                </tr>
            </thead>
          <tbody>
            <?php $no=1;?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td> <?php echo e($no++); ?> </td>
                <td> <?php echo e($value->code); ?></td>
                <td> <?php echo e($value->name); ?></td>
                <td>
                  <form id="delete-<?php echo e($value->id); ?>"
                    action="<?php echo e(action('PositionController@destroy', ['id' => $value->id])); ?>" method="POST"
                    style="display: none;">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                  </form>
                  <a class="btn btn-danger btn-xs" style="padding: 0px 5px 0px 5px;color: #fff"
                    onclick="remove(<?php echo e($value->id); ?>)">
                    Hapus
                  </a>
                  <a href=" <?php echo e(url('position/'.$value->id.'/edit')); ?> " class="btn btn-primary btn-xs" style="padding: 0px 5px 0px 5px"> Ubah </a>
                </td>
               
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>          
        </table>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>