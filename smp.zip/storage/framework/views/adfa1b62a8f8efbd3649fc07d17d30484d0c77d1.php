<?php echo $__env->make('layouts.admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <body class="app sidebar-mini rtl">
    <?php if(auth()->guard()->guest()): ?>

    <?php else: ?>
        <?php echo $__env->make("layouts.admin_header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
        <?php echo $__env->make("layouts.admin_slider", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
    <?php endif; ?>

     <?php echo $__env->yieldContent('content'); ?>
    
    <?php if(auth()->guard()->guest()): ?>
        
    <?php else: ?>
        <!-- Essential javascripts for application to work-->
        <script src="<?php echo e(asset('admin/js/jquery-3.2.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
        
        <script src="<?php echo e(asset('admin/js/jquery-ui.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('admin/js/select2.min.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

        <!-- The javascript plugin to display page loading on top-->
        <script src="<?php echo e(asset('admin/js/plugins/pace.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins/jquery.dataTables.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
        <script type="text/javascript">$('#sampleTable').DataTable();</script>
        <!-- Page specific javascripts-->
        <!-- Google analytics script-->
        
        <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
        <script src="/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>
        
        <script type="text/javascript">
            $(document).ready(function() {
                $("input.datepicker" ).datepicker({
                    dateFormat:'yy-mm-dd',
                    changeMonth: true,
                    changeYear: true
                });
                $('.js-example-basic-single').select2();
            });

            $(document).ready(function() {
                $('#dataTables').DataTable();
            } );
            $('select').select2();
        </script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/sweetalert/1.0.1/sweetalert.min.js"></script>
        <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('script'); ?>
  </body>
</html>