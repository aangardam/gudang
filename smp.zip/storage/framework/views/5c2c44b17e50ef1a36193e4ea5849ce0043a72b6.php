<?php $__env->startSection('content'); ?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Dasboard </h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="#">Dasboard </a></li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-6 col-lg-4">
            <div class="widget-small primary coloured-icon"><i class="icon fa fa-graduation-cap fa-3x"></i>
                <div class="info">
                    <br><h4>Jumlah Siswa/i Kelas VII</h4>
                    Siswa : <?php echo e($VIIL); ?> Orang <br>
                    Siswi : <?php echo e($VIIP); ?> Orang <br>
                    <b> Total : <?php echo e($VII); ?> Orang</b><br><br>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="widget-small info coloured-icon"><i class="icon fa fa-graduation-cap fa-3x"></i>
                <div class="info">
                    <br><h4>Jumlah Siswa/i Kelas VIII</h4>
                    Siswa : <?php echo e($VIIIL); ?> Orang <br>
                    Siswi : <?php echo e($VIIIP); ?> Orang <br>
                    <b> Total : <?php echo e($VIII); ?> Orang</b><br><br>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="widget-small warning coloured-icon"><i class="icon fa fa-graduation-cap fa-3x"></i>
                <div class="info">
                    <br><h4>Jumlah Siswa/i Kelas IX</h4>
                    Siswa : <?php echo e($IXL); ?> Orang <br>
                    Siswi : <?php echo e($IXP); ?> Orang <br>
                    <b> Total : <?php echo e($IX); ?> Orang</b><br><br>
                </div>
            </div>
        </div>
    </div>

    <!--  <div class="row">
         <div class="col-md-12">
            <div class="tile">

            </div>
         </div>
     </div> -->
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>