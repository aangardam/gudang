@extends('layouts.front')
@section('content')
<div class="banner">
</div>
<!-- //banner -->
<div class="special-services-1 w3">
	<div class="container">
		<h2 class="title">PRESTASI</h2>

		<div class="special-services-1-grids">
			@foreach($data as $key=>$value)
			<div class="col-md-3 special-services-1-grid">
				<div class="special-services-1-grid1">
					<center>
						<img src="{{$value->image}}" alt=" " class="img-responsive" width="250px">
					</center>
				</div>
				<h4>
					<p align="center">
						<font size="3"> <b>{{ $value->title }}</b> <br> ( Tanggal {{ $value->tanggal }} ) </font><br>
						<font size="3"> {{ $value->keterangan }} </font>
					</p>
					
					<?php
						// $title = $value->title;
						// $title = str_replace(' ','-',$title);
						// echo '<a href="'.url('Detail/'.$title).'" target="_blank">'.$value->title.'</a>';
					?>
				</h4>
			</div>
			@endforeach
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
	
	
@endsection