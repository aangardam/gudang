@extends('layouts.front')
@section('content')
<div class="banner">
</div>
<!-- //banner -->
<div class="special-services-1 w3">
	<div class="container">
		<h2 class="title">Kumpulan Kegiatan</h2>

		<div class="special-services-1-grids">
			@foreach($event as $key => $value)
			<div class="col-md-3 special-services-1-grid">
				<div class="special-services-1-grid1">
					<img src="imgevents/{{ $value->gambar }}" alt=" " class="img-responsive" width="250px">

				</div>
				<h4>
					<!-- <a href="">{{$value->nama}} </a> -->
					<?php
						echo '<a href="'.url('Detail2/'.$value->id).'">'.$value->nama.'</a>';
						
					?>
				</h4>
				<p>{{ strlen($value->deskripsi) > 100 ? substr($value->deskripsi,0,100)  : $value->deskripsi }}</p>
			</div>
			@endforeach
			<!-- <div class="col-md-3 special-services-1-grid">
				<div class="special-services-1-grid1">
					<img src="{{asset('front/images/3.jpg')}}" alt=" " class="img-responsive">
				</div>
				<h4>eligendi optio cum</h4>
				<p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil 
					impedit quo minus id quod.</p>

			</div>

			<div class="col-md-3 special-services-1-grid">
				<div class="special-services-1-grid1">
					<img src="{{asset('front/images/4.jpg')}}" alt=" " class="img-responsive">
				</div>
				<h4>cum soluta nobis est</h4>
				<p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil 
					impedit quo minus id quod.</p>

			</div>
			<div class="col-md-3 special-services-1-grid">
				<div class="special-services-1-grid1">
					<img src="{{asset('front/images/5.jpg')}}" alt=" " class="img-responsive">
				</div>
				<h4>quo minus id quod</h4>
				<p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil 
						impedit quo minus id quod.</p>

			</div> -->
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
	
	
@endsection