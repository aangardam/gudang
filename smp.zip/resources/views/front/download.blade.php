@extends('layouts.front')
@section('content')
<!-- banner -->
<div class="banner">
</div>
<!-- //banner -->
<div class="typo agileits-1">
	<div class="container">	
		<div class="page-header">
			<h3 class="bars">Download File</h3>
		</div>
		<!-- <p>Enable a hover state on table rows within a <code>&lt;tbody&gt;</code>.</p> -->
		<p><hr></p>
		<div class="bs-docs-example">
			<table width="50%">
				<thead>
					@foreach($download as $key=>$value)
						<tr>
							<td width="15"> {{$key+1}}. </td>
							<td> <a href="{{ $value->filename}}"> {{ $value->title }} </a></td>
						</tr>
					@endforeach
				</thead>
			</table>
			
		</div>
	</div>
</div>
@endsection