@extends('layouts.front')
@section('content')
<div class="banner">
</div>
<!-- //banner -->
<div class="special-services-1 w3">
	<div class="container">
		<h2 class="title">Kumpulan Berita</h2>

		<div class="special-services-1-grids">
			@foreach($berita as $key=>$value)
			<div class="col-md-3 special-services-1-grid">
				<div class="special-services-1-grid1">
					<img src="{{$value->image}}" alt=" " class="img-responsive" width="150px">

				</div>
				<h4>
					<?php
						$title = $value->title;
						$title = str_replace(' ','-',$title);
						echo '<a href="'.url('Detail/'.$title).'" target="_blank">'.$value->title.'</a>';
					?>
				</h4>
				{{--  <p>{{ strip_tags(strlen($value->isi) > 100) ? strip_tags(substr($value->isi,0,100))  : strip_tags($value->isi) }}</p>  --}}
			</div>
			@endforeach
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
	
	
@endsection