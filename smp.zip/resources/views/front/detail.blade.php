@extends('layouts.front')
@section('content')
<div class="banner">
</div>
<!-- //banner -->
<div class="about w3agile-1">
	<div class="container">
		<h1 class="title">Detail Berita</h1>
		<div class="about-info">
			<div class="col-md-9 about-grids">
				<div class="about-row"></div>
				<?php
				$title2 = str_replace('-',' ',$berita->title);
				?>
				<h4><b> {{ $title2 }} </b></h4>
				<h6><i>Ditulis Oleh : {{$berita->writer}}, Pada {{$berita->created_at}}</i></h6>
				<center>
					<img src="{{ asset($berita->image) }}" alt="" width="40%"/>
				</center>
				<p align="justify">
					{{ strip_tags($berita->isi) }}
				</p>
				<hr>
					<a href="{{ url('suka/'.$berita->id) }}"><img src="{{asset('image/images.png')}}" width="20" /></a> &nbsp; {{ $berita->suka }} Suka
					&nbsp;&nbsp;<a href="{{ url('tdksuka/'.$berita->id) }}"><img src="{{asset('image/Unlike.png')}}" width="20" /></a> &nbsp; {{ $berita->tdksuka }} Tidak Suka
					&nbsp;&nbsp; Dibaca {{ $berita->read+1 }} Kali
				<hr>
				<b> Komentar </b><br>
				{{--  perulangan isi komen  --}}
				@foreach ($coment as $item)
					<b>{{ $item->name }} </b> <i>Pada {{ $item->created_at }} </i><br> {{ $item->isi}} <hr>
				@endforeach
				<form method="post" action="{{url('addcoment')}}">
					{{ csrf_field() }}
					<input type="hidden" class="form-control" id="berita_id" required="" placeholder="Masukan Nama" name="berita_id" required="" value="{{$berita->id}}">
					<input type="hidden" class="form-control" id="telp" required="" placeholder="Masukan Nama" name="telp" required="" value="xxx">
					<div class="col-12">
						<div class="col-10">
							<input type="text" name="name" id="name" class="form-control" required="" placeholder="Nama">
						</div>
					</div>
					<div class="col-12">
						<div class="col-10">
							<input type="text" name="email" id="name" class="form-control" placeholder="Email">
						</div>
					</div>
					<div class="col-12">
						<div class="col-10">
							<textarea name="isi" id="isi" class="form-control" required="" placeholder="Tulis Komentar" cols="25"></textarea>
						</div>
					</div>
					
					<div class="col-12">
						<div class="col-10">
							<button type="submit" class="btn btn-default">Kirim</button>
						</div>
					</div>
						
				</form>
			</div>
			
			<div class="col-md-3 about-grids">
				<div class="pince">
					<div class="pince-justify">
						<h4> Visi </h4>
						<p>Terwujudnya lembaga pendidikan islam yang melahirkan generasi berilmu, beramal, dan berakhlakul karimah..</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		
		</div>
	</div>
	<div class="container">
		
	</div>
</div>
@endsection