@extends('layouts.admin')
@section('title')
| Kelas
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-list"></i> Kelas</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Kelas</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Ubah Kelas</h5>
        <hr>
        <form class="forms-sample" action="{{ url('kelas/'.$data->id)}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <input type="hidden" name="_method" value="put">
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> Kelas </label>
                </div>
                <div class="col-10">
                    <input type="text" name="name" id="name" class="form-control" required="" value="{{ $data->name }}">
                    
                </div>
            </div>

            {{--  <div class="form-group row">
                <div class="col-2">
                    <label> Url </label>
                </div>
                <div class="col-10">
                    <input type="text" name="alamat" id="name" class="form-control" value="{{ $data->alamat }}">
                </div>
            </div>  --}}

            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> Wali Kelas </label>
                </div>
                <div class="col-10">
                    <select name="staff_id" class="form-control" required>
                        //<option value="" selected disabled>- Pilih Wali Kelas -</option>
                        @foreach ($wali as $item=>$value)
                            @if ($value->id == $data->staff_id )
                                <option value="{{ $value->id }}" selected> {{ $value->name }} </option>
                            @else
                            <option value="{{ $value->id }}"> {{ $value->name }} </option>
                            @endif
                           
                        @endforeach
                    </select>
                </div>
            </div>
           
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('kelas') }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection