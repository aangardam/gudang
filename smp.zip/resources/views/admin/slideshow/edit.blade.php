@extends('layouts.admin')
@section('title')
| Galery
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-picture-o"></i> Galery</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Galery</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Edit Galery dan Slideshow</h5>
        <hr>
        <form class="forms-sample" action="{{ url('slide/'. $data->id) }}" enctype="multipart/form-data" method="POST">
            {{ csrf_field() }}
            <input type="hidden" name="id" value="{{ $data->id  }}" />
			<input type="hidden" name="_method" value="put">
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Judul <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Judul Gambar" name="title" required="" value="{{ $data->title}}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Deskripsi <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <textarea name="description" class="form-control" required> {{ $data->description }}</textarea>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Gambar </label>
                </div>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="title" placeholder="Judul Gambar" name="image" >
                </div>
            </div>
            
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('slide') }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection