@extends('layouts.admin')
@section('title')
| Galery
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-picture-o"></i> Galery</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Galery</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Tambah Galery dan Slideshow</h5>
        <hr>
        <form class="forms-sample" action="{{ url('slide')}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Judul <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Judul Gambar" name="title" required="">
                    {{--  <input type="hidden"  name="status" required="" value="1">  --}}
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Deskripsi <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <textarea name="description" class="form-control" required></textarea>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Tampilkan di slide show <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                   <select name="status" id="status" class="form-control">
                       <option value="1"> Ya </option>
                       <option value="0"> Tidak </option>
                   </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Tampilkan di Galeri <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                   <select name="tampil" id="tampil" class="form-control">
                       <option value="1"> Ya </option>
                       <option value="0"> Tidak </option>
                   </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Gambar <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="title" placeholder="Judul Gambar" name="image" required="">
                </div>
            </div>
            
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('slide') }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection