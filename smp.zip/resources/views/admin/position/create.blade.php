@extends('layouts.admin')
@section('title')
| Position
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-picture-o"></i> Position</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Position</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Tambah Position</h5>
        <hr>
        <form class="forms-sample" action="{{ url('position')}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Kode <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Kode" name="code" required="">
                    <input type="hidden"  name="writer" required="" value="Admin">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Jabatan <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Jabatan" name="name" required="">
                    <input type="hidden"  name="writer" required="" value="Admin">
                </div>
            </div>
            </div>
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('position') }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection