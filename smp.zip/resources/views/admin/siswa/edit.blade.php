@extends('layouts.admin')
@section('title')
| Siswa
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-user"></i> Siswa</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Siswa</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Tambah Siswa</h5>
        <hr>
        <form class="forms-sample" action="{{ url('Studentsupdate/'.$data->id)}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <input type="hidden" name="id" value="{{ $data->id  }}" />
            <input type="hidden" name="_method" value="put">
            
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> NIS </label>
                </div>
                <div class="col-4">
                    <input type="text" name="nis" id="nis" class="form-control" required="" value="{{ $data->nis }}">
                </div>
                <div class="col-2">
                    <label><small class="text-danger">*</small> Nama </label>
                </div>
                <div class="col-4">
                    <input type="text" name="name" id="name" class="form-control" required="" value="{{ $data->name }}">
                </div>
            </div>
           
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> JK </label>
                </div>
                <div class="col-4">
                    <select class="form-control" name="jk">
                        @if ($data->jk=='L')
                            <option value="L"> Laki - Laki </option>
                            <option value="P"> Perempuan </option>
                        @else
                            <option value="P"> Perempuan </option>
                            <option value="L"> Laki - Laki </option>
                        @endif
                    </select>
                </div>
                <div class="col-2">
                    <label> Foto </label>
                </div>
                <div class="col-4">
                    <input type="file" name="image" id="pob" class="form-control" >
                </div>
            </div>

            <div class="form-group row">
                <div class="col-2">
                    <label> Tempat Lahir </label>
                </div>
                
                <div class="col-4">
                    <input type="text" name="pob" id="pob" class="form-control" value="{{ $data->pob }}">
                </div>
                <div class="col-2">
                    <label> Tanggal Lahir </label>
                </div>
                <div class="col-4">
                    <input type="text" name="dob" class="form-control datepicker" value="{{ $data->dob }}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-2">
                    <label> E-Mail </label>
                </div>
                <div class="col-4">
                    <input type="text" name="email" id="email" class="form-control" value="{{ $data->email }}">
                </div>

                <div class="col-2">
                    <label> No HP </label>
                </div>
                <div class="col-4">
                    <input type="text" name="hp" id="hp" class="form-control" value="{{ $data->hp }}">
                </div>
            </div>

            <input type="hidden" name="kelas_id" id="kelas_id" class="form-control" value="{{ $data->kelas_id }}">

            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('Students/'.$data->kelas_id) }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection