@extends('layouts.admin')
@section('title')
| Download File
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-cloud-download"></i> Download File</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-cloud-download"></i></li>
      <li class="breadcrumb-item"><a href="#">Download File</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Tambah File Download</h5>
        <hr>
        <form class="forms-sample" action="{{ url('DownloadFile')}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Title <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Judul Gambar" name="title" required="">
                    <input type="hidden"  name="tampil" required="" value="1"> 
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>File<small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="title" placeholder="Judul Gambar" name="filename" required="">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Tampilkan<small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                   <select name="status" id="status" class="form-control">
                       <option value="1"> Ya </option>
                       <option value="0"> Tidak </option>
                   </select>
            </div>
                </div>
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('DownloadFile') }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection