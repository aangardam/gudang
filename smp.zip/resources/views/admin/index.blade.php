@extends('layouts.admin')
@section('content')
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Dasboard </h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="#">Dasboard </a></li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-6 col-lg-4">
            <div class="widget-small primary coloured-icon"><i class="icon fa fa-graduation-cap fa-3x"></i>
                <div class="info">
                    <br><h4>Jumlah Siswa/i Kelas VII</h4>
                    Siswa : {{ $VIIL }} Orang <br>
                    Siswi : {{ $VIIP }} Orang <br>
                    <b> Total : {{ $VII }} Orang</b><br><br>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="widget-small info coloured-icon"><i class="icon fa fa-graduation-cap fa-3x"></i>
                <div class="info">
                    <br><h4>Jumlah Siswa/i Kelas VIII</h4>
                    Siswa : {{ $VIIIL }} Orang <br>
                    Siswi : {{ $VIIIP }} Orang <br>
                    <b> Total : {{ $VIII }} Orang</b><br><br>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="widget-small warning coloured-icon"><i class="icon fa fa-graduation-cap fa-3x"></i>
                <div class="info">
                    <br><h4>Jumlah Siswa/i Kelas IX</h4>
                    Siswa : {{ $IXL }} Orang <br>
                    Siswi : {{ $IXP }} Orang <br>
                    <b> Total : {{ $IX }} Orang</b><br><br>
                </div>
            </div>
        </div>
    </div>

    <!--  <div class="row">
         <div class="col-md-12">
            <div class="tile">

            </div>
         </div>
     </div> -->
</main>
@endsection