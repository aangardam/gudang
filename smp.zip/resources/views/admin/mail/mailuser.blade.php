Hai, <b>{{ $user->name }}</b><hr>
Selamat bergabung bersama <b>palupaku.com</b><br>
Silahkan login menggunakan email <b>{{ $user->email }}}</b> dengan password anda <b>{{ $pass }}</b><br>
