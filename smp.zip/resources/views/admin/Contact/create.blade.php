@extends('layouts.admin')
@section('title')
| Contact
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-picture-o"></i> Contact</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-address-book"></i></li>
      <li class="breadcrumb-item"><a href="#">Contact</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Tambah File Download</h5>
        <hr>
        <form class="forms-sample" action="{{ url('Contact')}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Nama <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Nama" name="name" required="">
                    <input type="hidden"  name="tampil" required="" value="1"> 
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Email <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Email" name="email" required="">
                    <input type="hidden"  name="tampil" required="" value="1"> 
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Telepon <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Telepon" name="telp" required="">
                    <input type="hidden"  name="tampil" required="" value="1"> 
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Isi <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <textarea name="isi" class="form-control" required></textarea>
                </div>
            </div>
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('Contact') }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection