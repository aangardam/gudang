
@extends('layouts.admin')
@section('title')
| Berita
@endsection
@section('script')
<script>
  window.remove = function (id) {
      event.preventDefault();
  
      swal({
          title: "Apakah Anda Yakin?",
          text: "Berita yang sudah di hapus tidak dapat di kembalikan!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Ya, Hapus!",
          cancelButtonText: 'Batal',
          closeOnConfirm: false,
          html: false
      }, function () {
          document.getElementById('delete-' + id).submit();
          swal("Berhasil!",
              "Berita sudah dihapus.",
              "success");
      });
  };
</script>
@endsection
@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-file"></i> Berita</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Berita</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div align="right">
            <a href="{{ url ('news/create') }}" class="btn btn-primary btn-sm">
                <b><i class="fa fa-plus"></i></b> Berita
            </a>
        </div>
        <hr>
        <table class="table table-hover table-bordered" id="sampleTable">
            <thead>
                <tr>
                  <td><b> No </b></td>
                  <td><b> Image </b></td>
                  <td><b> Title </b></td>
                  <td><b> Isi </b></td>
                  <td><b> Penulis </b></td>
                  <td><b> Comment </b></td>
                  <td><b>  </b></td>

                </tr>
            </thead>
          <tbody>
            <?php $no=1;?>
            @foreach($data as $key=>$value)
              <tr>
                <td> {{ $key+1 }} </td>
                <td><img src="{{ $value->image }}" width="55"> </td>
                <td> {{ $value->title }}</td>
                <td> {{ $value->isi }}</td>
                <td> {{ $value->writer }} </td>
                <td>
                  <?php
                    $tgl = date('Y-m-d');
                    $tgl2 = $tgl2 = date('Y-m-d', strtotime('+1 days', strtotime($tgl)));
                    $jmlcoment = DB::table('coment_news')
                                                     ->where('berita_id','=',$value->id)
                                                     ->where('created_at','>',$tgl)
                                                     ->where('created_at','<',$tgl2)
                                                     ->count();
                  ?>
                  <a href="{{ url('Comentnews/'.$value->id) }}"><i class="app-menu__icon fa fa-comment"></i>{{$jmlcoment}} </a>
                </td>
                <td>
                  <form id="delete-{{$value->id}}"
                    action="{{ action('NewsController@destroy', ['id' => $value->id]) }}" method="POST"
                    style="display: none;">
                    {{ csrf_field() }}
                    {{ method_field('DELETE') }}
                  </form>
                  <a class="btn btn-danger btn-xs" style="padding: 0px 5px 0px 5px;color: #fff"
                    onclick="remove({{$value->id}})">
                    Hapus
                  </a>
                  <a href=" {{  url('news/'.$value->id.'/edit') }} " class="btn btn-primary btn-xs" style="padding: 0px 5px 0px 5px"> Ubah </a>
                </td>
               
              </tr>
            @endforeach
          </tbody>        	
        </table>
      </div>
    </div>
  </div>
</main>
@endsection