@extends('layouts.admin')
@section('title')
| Berita
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-picture-o"></i> Berita</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Berita</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Ubah Berita</h5>
        <hr>
        <form class="forms-sample" action="{{ url('news/'.$data->id)}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <input type="hidden" name="id" value="{{ $data->id  }}" />
			<input type="hidden" name="_method" value="put">
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Judul <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Judul Gambar" name="title" required="" value="{{ $data->title}}">
                    <input type="hidden"  name="writer" required="" value="Admin">
                </div>
            </div>
           
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Gambar </label>
                </div>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="title" placeholder="Judul Gambar" name="image" >
                </div>
            </div>
            
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Isi <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <textarea name="isi" class="form-control" required> {{$data->isi}} </textarea>
                </div>
            </div>
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('news') }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection