
@extends('layouts.admin')
@section('title')
| Prestasi
@endsection
@section('script')
<script>
  window.remove = function (id) {
      event.preventDefault();
  
      swal({
          title: "Apakah Anda Yakin?",
          text: "Prestasi yang sudah di hapus tidak dapat di kembalikan!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Ya, Hapus!",
          cancelButtonText: 'Batal',
          closeOnConfirm: false,
          html: false
      }, function () {
          document.getElementById('delete-' + id).submit();
          swal("Berhasil!",
              "Prestasi sudah dihapus.",
              "success");
      });
  };
</script>
@endsection
@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-trophy"></i> Prestasi</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Prestasi</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div align="right">
            <a href="{{ url ('achievement/create') }}" class="btn btn-primary btn-sm">
                <b><i class="fa fa-plus"></i></b> Prestasi
            </a>
        </div>
        <hr>
        <table class="table table-hover table-bordered" id="sampleTable">
            <thead>
                <tr>
                  <td><b> No </b></td>
                  <td><b> Title </b></td>
                  <td><b> Image </b></td>
                  <td><b> Keterangan </b></td>
                  <td><b> Tanggal </b></td>
                  <td><b>  </b></td>

                </tr>
            </thead>
          <tbody>
            <?php $no=1;?>
            @foreach($data as $key=>$value)
              <tr>
                <td> {{ $key+1 }} </td>
                <td> {{ $value->title }}</td>
                <td><img src="{{ $value->image }}" width="55"> </td>
                <td> {{ $value->keterangan }}</td>
                <td> {{ $value->tanggal }} </td>
                <td>
                  <form id="delete-{{$value->id}}"
                    action="{{ action('PrestasiController@destroy', ['id' => $value->id]) }}" method="POST"
                    style="display: none;">
                    {{ csrf_field() }}
                    {{ method_field('DELETE') }}
                  </form>
                  <a class="btn btn-danger btn-xs" style="padding: 0px 5px 0px 5px;color: #fff"
                    onclick="remove({{$value->id}})">
                    Hapus
                  </a>
                  <a href=" {{  url('achievement/'.$value->id.'/edit') }} " class="btn btn-primary btn-xs" style="padding: 0px 5px 0px 5px"> Ubah </a>
                </td>
               
              </tr>
            @endforeach
          </tbody>        	
        </table>
      </div>
    </div>
  </div>
</main>
@endsection