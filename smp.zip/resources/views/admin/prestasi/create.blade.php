@extends('layouts.admin')
@section('title')
| Prestasi
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-trophy""></i> Prestasi</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Prestasi</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Tambah Prestasi</h5>
        <hr>
        <form class="forms-sample" action="{{ url('achievement')}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Judul <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" placeholder="Judul Prestasi" name="title" required="">
                    <input type="hidden" class="form-control" id="tanggal" placeholder="Judul Prestasi" name="tanggal" required="" value="<?php echo date('Y-m-d')?>" >
                </div>
            </div>
           
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Gambar <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="title" placeholder="Judul Gambar" name="image" required="">
                </div>
            </div>
            
            <div class="form-group row">
                <div class="col-sm-2">
                    <label>Keterangan <small class="text-danger">*</small></label>
                </div>
                <div class="col-sm-10">
                    <textarea name="keterangan" class="form-control" required rows="8"></textarea>
                </div>
            </div>
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection