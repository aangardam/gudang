@extends('layouts.admin')
@section('title')
| Staff
@endsection

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-picture-o"></i> Staff</h1>
      {{-- <p>Start a beautiful journey here</p> --}}
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Staff</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h5>Tambah Staff</h5>
        <hr>
        <form class="forms-sample" action="{{ url('staff')}}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> NIP </label>
                </div>
                <div class="col-4">
                    <input type="text" name="nip" id="name" class="form-control" required="">
                </div>
            {{--  </div>
            <div class="form-group row">  --}}
                <div class="col-2">
                    <label><small class="text-danger">*</small> NUPTK </label>
                </div>
                <div class="col-4">
                    <input type="text" name="nuptk" id="nuptk" class="form-control" required="">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> Nama </label>
                </div>
                <div class="col-4">
                    <input type="text" name="name" id="name" class="form-control" required="">
                </div>

                <div class="col-2">
                    <label><small class="text-danger">*</small> Jabatan </label>
                </div>
                <div class="col-4">
                    <select name="position_id" class="form-control" required>
                        <option value="" selected disabled>- Pilih Jabtan -</option>
                        @foreach ($data as $jabatan)
                            <option value="{{ $jabatan->id }}"> {{ $jabatan->name }}</option>                            
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> JK </label>
                </div>
                <div class="col-4">
                    <select class="form-control" name="jk">
                        <option value="L"> Laki - Laki </option>
                        <option value="P"> Perempuan </option>
                    </select>
                </div>
                <div class="col-2">
                    <label> Foto </label>
                </div>
                <div class="col-4">
                    <input type="file" name="image" id="pob" class="form-control" >
                </div>
            </div>

            <div class="form-group row">
                <div class="col-2">
                    <label> Tempat Lahir </label>
                </div>
                
                <div class="col-4">
                    <input type="text" name="pob" id="pob" class="form-control" >
                </div>
                <div class="col-2">
                    <label> Tanggal Lahir </label>
                </div>
                <div class="col-4">
                <input type="text" name="dob" class="form-control datepicker" value="{{ date('1995-01-01') }}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> Email </label>
                </div>
                <div class="col-4">
                    <input type="email" name="email" id="email" class="form-control" >
                </div>

                <div class="col-2">
                    <label> No HP </label>
                </div>
                <div class="col-4">
                    <input type="text" name="hp" id="hp" class="form-control" >
                </div>
            </div>

            <div class="form-group row">
                <div class="col-2">
                    <label><small class="text-danger">*</small> Pendidikan </label>
                </div>
                <div class="col-4">
                    <select name="pendidikan" class="form-control">
                        <option> SMA </option>
                        <option> D3 </option>
                        <option> S1 </option>
                        <option> S2 </option>
                    </select>
                </div>

                <div class="col-2">
                    <label> Lulusan </label>
                </div>
                <div class="col-4">
                    <input type="text" name="school" id="hp" class="form-control" >
                </div>
            </div>
            {{--  <div class="form-group row">
                <div class="col-2">
                    <label> Foto </label>
                </div>
                <div class="col-4">
                    <input type="file" name="image" id="pob" class="form-control" >
                </div>
            </div>  --}}
            <div class="ibox-footer text-right">
                <button type="submit" class="btn btn-success mr-2">Submit</button>
                <a href="{{ url('staff') }}" class="btn btn-light">Batal</a>
            </div>
        </form>
      </div>
    </div>
  </div>
</main>
@endsection