<?php
// $gallery = DB::table('slideshows')->count();
  $user = Auth::user();
  $staff = DB::table('staff')->where('user_id',$user->id)->first();
?>
<aside class="app-sidebar">
  <div class="app-sidebar__user">
    <!-- <img class="app-sidebar__user-avatar" src="https://s3.amazonaws.com/uifaces/faces/twitter/jsa/48.jpg" alt="User Image"> -->
    @if($staff->foto == '')
      <img src="{{ asset('image/logo-smp.jpg') }}" class="app-sidebar__user-avatar" alt="User Image" width="25%">
    @else
      <img src="{{ $staff->foto }} " class="app-sidebar__user-avatar" alt="User Image" width="25%">
    @endif
    <div>
      <p class="app-sidebar__user-name">{{Auth::user()->name }}</p>
      <p class="app-sidebar__user-designation">{{Auth::user()->email }}</p>
    </div>
  </div>
  <ul class="app-menu">
    <li>
      <a class="app-menu__item" href="{{ url('home')}}"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a>
    </li>
    <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-list"></i><span class="app-menu__label">Front End</span><i class="treeview-indicator fa fa-angle-right"></i></a>
      <ul class="treeview-menu">
        <li><a class="treeview-item" href="{{ url('slide')}}"><i class="app-menu__icon fa fa-picture-o"></i><span class="app-menu__label">Galery</span></a></li>
        <li><a class="treeview-item" href="{{ url('news')}}"><i class="app-menu__icon fa fa-file"></i><span class="app-menu__label">Berita</span></a></li>
        <li><a class="treeview-item" href="{{ url('achievement')}}"><i class="app-menu__icon fa fa-trophy"></i><span class="app-menu__label">Prestasi</span></a></li>
        <li><a class="app-menu__item" href="{{ url('DownloadFile')}}"><i class="app-menu__icon fa fa-cloud-download"></i><span class="app-menu__label">Download File</span></a></li>
        <li><a class="app-menu__item" href="{{ url('Contact')}}"><i class="app-menu__icon fa fa-address-book"></i><span class="app-menu__label">Contact</span></a></li>
      </ul>
    </li>

    <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-list"></i><span class="app-menu__label">Master</span><i class="treeview-indicator fa fa-angle-right"></i></a>
      <ul class="treeview-menu">
          <li><a class="app-menu__item" href="{{ url('position')}}"><i class="app-menu__icon fa fa-file"></i><span class="app-menu__label">Position</span></a></li>
        <li><a class="treeview-item" href="{{ url('staff')}}"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Staff</span></a></li>
        <li><a class="treeview-item" href="{{ url('kelas')}}"><i class="app-menu__icon fa fa-list"></i><span class="app-menu__label">Kelas</span></a></li>
      </ul>
    </li>

    <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-list"></i><span class="app-menu__label">Siswa</span><i class="treeview-indicator fa fa-angle-right"></i></a>
      <ul class="treeview-menu">
        <?php
            $menu_0 = \App\Models\Kelas::all();
            foreach ($menu_0 as $key) {
              echo "<li><a href=" . url('Students').'/'.($key->id) ." class='treeview-item'><i class='app-menu__icon fa fa-graduation-cap' aria-hidden='true'></i><span class='app-menu__label'> Kelas $key->name </span></a> </li>";
            }
        ?>
      </ul>
    </li>
    
  </ul>
</aside>