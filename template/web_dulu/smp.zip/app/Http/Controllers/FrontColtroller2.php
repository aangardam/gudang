<?php

namespace App\Http\Controllers;
use App\Models\Guru;
use App\Models\Contacts;
use App\Models\album;
use App\Models\galery;
use App\Models\berita;
use App\Models\event;
use Illuminate\Http\Request;
use\App\Models\download;
use\App\Models\comment;
use\App\Models\comment2;

class FrontColtroller2 extends Controller
{
    public function about()
    {
       
        return view('front.about');
    }

    public function teachers()
    {
        
        $Guru = Guru::all()->where('jabatan','!=','TU');
        return view('front.guru',compact('Guru'));
    }

    public function contact()
    {
       
        return view('front.kontak');
    }
    public function news()
    {
       
        $berita = berita::all();
        return view('front.berita',compact('berita'));
    }

    public function detail($id)
    {
        
        $berita = berita::find($id);
        $comment = comment::all()->where('berita_id','==',$id);
        return view('front.detail',compact('berita','comment'));
    }


    public function events()
    {
        
        $event = event::all();
        return view('front.kegiatan',compact('event'));
    }

    public function detail2($id)
    {
        
        $event = event::find($id);
        $comment2 = comment2::all()->where('evnets_id','==',$id);
        return view('front.detail2',compact('event','comment2'));
    }

    public function gallery()
    {
       
        $album = album::all();
        $galery = galery::all();
        return view('front.foto',compact('album','galery'));
    }
    public function addcontact(Request $request)
    {
        $data = $request->all();
        $Contacts = Contacts::create($data);
        return redirect('contact');
    }
    public function addcoment(Request $request)
    {
        $data = $request->all();
        $comment = comment::create($data);
        return redirect('contact');
    }

    public function addcoment2(Request $request)
    {
        $data = $request->all();
        $comment2 = comment2::create($data);
        return redirect('contact');
    }

    public function download()
    {
        $download = download::all()->where('publish','==','Y');
        return view('front.download',compact('download'));

    }
}