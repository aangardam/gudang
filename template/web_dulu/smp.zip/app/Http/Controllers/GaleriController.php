<?php

namespace App\Http\Controllers;
use App\Models\galery;
use App\Models\album;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

class GaleriController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $galery = galery::all();
        $album = album::select('nama','id')->get();
         
        return view('admin.galeri',compact('galery','album'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $gambar = $request->file('gambar')->getClientOriginalName();
        $destination ='img';
        $request->file('gambar')->move($destination,$gambar);
        $data['gambar']=$gambar;
        $galery =galery::create($data);
       
        return redirect('galeri')->with('message','Data berhasil ditambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $id = input::get('id');
        $album_id = input::get('album_id');
        $judul = input::get('judul');
        $deskripsi = input::get('deskripsi');
        if($request->file('gambar')==''){
            galery::where('id',$id)->update(array(
                    'album_id'=>$album_id,
                    'judul'=>$judul,
                    'deskripsi'=>$deskripsi
                ));
        }else{
            $gambar = input::get('gambar');
            $gambar = $request->file('gambar')->getClientOriginalName();
            $destination ='img';
            $request->file('gambar')->move($destination,$gambar);
            $data['gambar']=$gambar;
            galery::where('id',$id)->update(array(
                    'album_id'=>$album_id,
                    'judul'=>$judul,
                    'deskripsi'=>$deskripsi,
                    'gambar'=>$gambar
                ));
        }
        return redirect('galeri')->with('message','Data telah diubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
