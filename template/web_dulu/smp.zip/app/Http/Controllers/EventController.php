<?php

namespace App\Http\Controllers;
use App\Models\event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $event = event::all();
        return view('admin.kegiatan',compact('event'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $gambar = $request->file('gambar')->getClientOriginalName();
        $destination ='imgevents';
        $request ->file('gambar')->move($destination,$gambar);
        $data['gambar']=$destination."/".$gambar;
        $event =event::create($data);
        return redirect('kegiatan')->with('message','Data Berhasil disimpan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $id = Input::get('id');
        $nama = input::get('nama');
        $tanggal = input::get('tanggal');
        $deskripsi = input::get('deskripsi');
        if($request->file('gambar')==''){
            event::where('id',$id)->update(array(
                'nama'=>$nama,
                'tanggal'=>$tanggal,
                'deskripsi'=>$deskripsi
                ));
        }else{
            $gambar = input::get('gambar');
            $gambar = $request->file('gambar')->getClientOriginalName();
            $destination ='imgevents';
            $request ->file('gambar')->move($destination,$gambar);
            $data['gambar']=$destination."/".$gambar;
            event::where('id',$id)->update(array(
                'nama'=>$nama,
                'tanggal'=>$tanggal,
                'deskripsi'=>$deskripsi,
                'gambar'=>$gambar
                ));

        }
        return redirect('kegiatan')->with('message','Data telah di ubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $event = event::find($id);
        $event ->delete();
        return redirect('kegiatan')->with('message','Data berhasil dihapus');
    }
}
