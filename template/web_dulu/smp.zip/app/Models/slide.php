<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class slide extends Model
{
    protected $fillable=['id','judul','gambar','status'];
    
}
