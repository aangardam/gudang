<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class event extends Model
{
    protected $fillable=['nama','tanggal','deskripsi','gambar'];

    public function comment2()
	{
		return $this->hasMany('App\Models\comment2','evnets_id');
	}
}
