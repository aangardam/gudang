<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Guru extends Model
{
    protected $fillable=['id','nama','jabatan','mengajar','pendidikan','foto'];
}
