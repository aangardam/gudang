<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class download extends Model
{
    protected $fillable=['judul','file','publish'];
}
