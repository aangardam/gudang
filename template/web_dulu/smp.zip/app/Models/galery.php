<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class galery extends Model
{
    protected $fillable=['id','album_id','judul','deskripsi','gambar'];

    public function album()
    {
    	return $this->belongsTo('App\Models\album','album_id');
    }
}
