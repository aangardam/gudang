<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class comment2 extends Model
{
    protected $fillable=['id','evnets_id','nama','email','hp','isi'];
}
