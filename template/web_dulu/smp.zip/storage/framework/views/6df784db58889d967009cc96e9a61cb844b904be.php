<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data User</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah User </a>
            </td>
            <!-- Modal -->
            <form action="<?php echo e(url('user')); ?>" method="post">
           <?php echo e(csrf_field()); ?>

            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah User</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Nama : <input type="text" name="nama" class="form-control" required="">
                    Email : <input type="email" name="email" class="form-control" required="">
                    Password : <input type="password" name="pass" class="form-control" required="">
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </tr>
        </table>
        </div>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <!-- <th>Aktif</th> -->
                </tr>
              </thead>
              <?php $i=1;?>
              <?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i++); ?></td>
                  <td><?php echo e($value->name); ?></td>
                  <td><?php echo e($value->email); ?></td>
                  <td>
                    <a href="#" data-toggle="modal" data-target="#<?php echo e($value->id); ?>">Edit</a> ||
                     <form action="<?php echo e(url('albumupdate')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" class="form-control" value="<?php echo e($value->id); ?>">

                         <div id="<?php echo e($value->id); ?>" class="modal fade" role="dialog">
                          <div class="modal-dialog">
                            <!-- konten modal-->
                            <div class="modal-content">
                              <!-- heading modal -->
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Form Edit User</h4>
                              </div>
                              <!-- body modal -->
                              <div class="modal-body">
                                <div class="modal-body">
                                  Nama : <input type="text" name="nama" class="form-control" value="<?php echo e($value->nama); ?>">

                                  Email : <input type="email" name="email" class="form-control" value="<?php echo e($value->email); ?>">

                                  Password : <input type="password" name="pass" class="form-control">
                                  <p><i>Isi Jika password akan di ubah</i></p>
                                </div>
                              </div>
                              <!-- footer modal -->
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <button type="reset" class="btn btn-default">Cancel</button>
                              </div>
                            </div>
                          </div>
                        </div>
                    </form>
                    
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>