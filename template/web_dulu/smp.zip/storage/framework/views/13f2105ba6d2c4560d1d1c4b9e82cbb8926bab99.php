<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Download</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Download </a>
            </td>
            <!-- Modal -->
            <form action="<?php echo e(url('download')); ?>" method="post" enctype="multipart/form-data">
           <?php echo e(csrf_field()); ?>

            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah Download</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Judul : <input type="text" name="judul" class="form-control">
                    File : <input type="file" name="file" class="form-control">
                    Publish :
                          <select name="publish" class="form-control">
                            <option value="Y">Ya</option>
                            <option value="N">Tidak</option>
                          </select>
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </tr>
        </table>
        </div>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Judul</th>
                  <!-- <th>File</th> -->
                  <th>Publish</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $download; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($key+1); ?></td>
                  <td>
                    <a href="<?php echo e($value->file); ?>"><?php echo e($value->judul); ?></a>
                  </td>
                  <!-- <td>
                    <a href="<?php echo e($value->file); ?>" target="blank"><?php echo e($value->file); ?></a>
                    
                  </td> -->
                  <td><?php echo e($value->publish); ?></td>
                  <!-- <td> <img src="<?php echo e($value->file); ?>" alt="" width="150px" /></td> -->
                  <td>
                    <a href="#" data-toggle="modal" data-target="#<?php echo e($value->id); ?>">  Edit </a>
                    <form action="<?php echo e(url('download/' . $value->id)); ?>" method="post" enctype="multipart/form-data">
                     <?php echo e(csrf_field()); ?>

                     <input type="hidden" name="_method" value="put">
                     <div id="<?php echo e($value->id); ?>" class="modal fade" role="dialog">
                      <div class="modal-dialog">
                        <!-- konten modal-->
                        <div class="modal-content">
                          <!-- heading modal -->
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Form Edit Download</h4>
                          </div>
                          <!-- body modal -->
                          <div class="modal-body">
                            Judul : <input type="text" name="judul" class="form-control" value="<?php echo e($value->judul); ?>">

                            <input type="hidden" name="id" class="form-control" value="<?php echo e($value->id); ?>">
                            File : <input type="file" name="file" class="form-control">
                            Publish :<select name="publish" class="form-control">
                                      <!-- <option value="Y">Ya</option>
                                      <option value="T">Tidak</option> -->
                                      <?php if($value->publish=='Y'): ?>
                                        <option value="Y">Ya</option>
                                        <option value="N">Tidak</option>
                                      <?php else: ?>{
                                        <option value="N">Tidak</option>
                                        <option value="Y">Ya</option>
                                      }
                                      <?php endif; ?>
                                    </select>

                          </div>
                          <!-- footer modal -->
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <button type="reset" class="btn btn-default">Cancel</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                  <a href="<?php echo e(url('download/'.$value->id)); ?>" onclick="return confirm('Yakin mau hapus data ini?')"> Hapus </a>
                  </td> 
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>