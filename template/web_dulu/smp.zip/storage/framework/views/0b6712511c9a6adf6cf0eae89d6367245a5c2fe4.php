<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Pesan</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
        </div>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Pesan</th>
                  <th>Update</th>
                </tr>
              </thead>
              <?php $i=1;?>
              <?php $__currentLoopData = $Contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i++); ?></td>
                  <td><?php echo e($value->nama); ?></td>
                  <td><?php echo e($value->email); ?></td>
                  <td><?php echo e($value->pesan); ?></td>
                  <td>
                    <?php
                         echo '<a href="'.url('Contactsdestroy/'.$value->id).'" onclick="return confirm(\'Yakin mau hapus data ini?\')" > Hapus </a>';
                      ?>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>