<?php $__env->startSection('content'); ?>
<!-- banner -->
<div class="banner">
</div>
<!-- //banner -->
<div class="typo agileits-1">
	<div class="container">	
		<div class="page-header">
			<h3 class="bars">Staff Pengajar SMP IT Darurrohmat</h3>
		</div>
		<!-- <p>Enable a hover state on table rows within a <code>&lt;tbody&gt;</code>.</p> -->
		<p><hr></p>
		<div class="bs-docs-example">
			<table class="table table-hover">
				<thead>
					<tr>
						<th>No</th>
						<th>Nama</th>
						<th>Jabatan</th>
						<th>Pendidikan Terakhir</th>
						<th>Foto</th>
					</tr>
				</thead>
				<tbody>
                <?php $i=1;?>
                <?php $__currentLoopData = $Guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($value->nama); ?></td>
                    <td><?php echo e($value->jabatan); ?></td>
                    <td><?php echo e($value->pendidikan); ?></td>
                    <td> <img src="/img/<?php echo e($value->foto); ?>" width="100px" alt=""> </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>