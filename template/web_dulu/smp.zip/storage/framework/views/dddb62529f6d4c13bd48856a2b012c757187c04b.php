<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Berita</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Berita </a>
            </td>
            <!-- Modal -->
            <form action="<?php echo e(url('berita')); ?>" method="post" enctype="multipart/form-data">
           <?php echo e(csrf_field()); ?>

            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah Berita</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Judul : <input type="text" name="judul" class="form-control">
                    Penulis : <input type="text" name="penulis" class="form-control">
                    Isi : <textarea name="isi" class="form-control" rows="10"></textarea>
                    Gambar : <input type="file" name="gambar" class="form-control">
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </tr>
        </table>
        </div>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Judul</th>
                  <th>Tanggal</th>
                  <th>Isi</th>
                  <th>Penulis</th>
                  <th>Gambar</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($key+1); ?></td>
                  <td><?php echo e($value->judul); ?></td>
                  <td><?php echo e($value->created_at); ?></td>
                  <td>
                    <?php echo e(strlen($value->isi) > 100 ? substr($value->isi,0,100) . ". . .Readmore" : $value->isi); ?>

                  </td>
                  <td><?php echo e($value->penulis); ?></td>
                  <td> <img src="<?php echo e($value->gambar); ?>" alt="" width="150px" /></td>
                  <td>
                    <a href="#" data-toggle="modal" data-target="#<?php echo e($value->id); ?>">  Edit </a>
                    <form action="<?php echo e(url('berita/' . $value->id)); ?>" method="post" enctype="multipart/form-data">
                     <?php echo e(csrf_field()); ?>

                     <input type="hidden" name="_method" value="put">
                     <div id="<?php echo e($value->id); ?>" class="modal fade" role="dialog">
                      <div class="modal-dialog">
                        <!-- konten modal-->
                        <div class="modal-content">
                          <!-- heading modal -->
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Form Edit Berita</h4>
                          </div>
                          <!-- body modal -->
                          <div class="modal-body">
                            Judul : <input type="text" name="judul" class="form-control" value="<?php echo e($value->judul); ?>">

                            <input type="hidden" name="id" class="form-control" value="<?php echo e($value->id); ?>">

                            Penulis : <input type="text" name="penulis" class="form-control" value="<?php echo e($value->penulis); ?>">
                            Isi : <textarea name="isi" class="form-control" rows="10"><?php echo e($value->isi); ?></textarea>
                            Gambar : <input type="file" name="gambar" class="form-control">
                          </div>
                          <!-- footer modal -->
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <button type="reset" class="btn btn-default">Cancel</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                  <!-- <a href="<?php echo e(url('berita/' . $value->id)); ?>" onclick="return confirm('Yakin mau hapus data ini?')"> Hapus </a> -->
                  <form method="post" action="<?php echo e(url('berita/' . $value->id)); ?>">
                    <input type="hidden" name="_method" value="DELETE">
                    <?php echo e(csrf_field()); ?>

                      <!-- <a href="<?php echo e(url('comment/'.$value->id)); ?>" onclick="return confirm('Yakin mau hapus data ini?')"> Hapus </a>   -->
                      <input type="submit" value="delete" onclick="return confirm('Yakin mau hapus data ini?')" >
                    </form>
                  </td> 
                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>