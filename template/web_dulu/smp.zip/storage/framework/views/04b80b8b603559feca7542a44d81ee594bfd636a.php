<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Galeri</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Galeri </a>
            </td>
            <!-- Modal -->
            <form action="<?php echo e(url('galeristore')); ?>" method="post" enctype="multipart/form-data">
           <?php echo e(csrf_field()); ?>

            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah Galeri</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Album :
                          <select name="album_id" class="form-control">
                            <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($value->id); ?>"><?php echo e($value->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    Judul : <input type="text" name="judul" class="form-control">
                    Deskripsi : <textarea name="deskripsi" class="form-control"></textarea>
                    Gambar : <input type="file" name="gambar" class="form-control">
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </tr>
        </table>
        </div>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Album</th>
                  <th>Judul</th>
                  <th>Deskripsi</th>
                  <th>Gambar</th>
                  <th>Update</th>
                </tr>
              </thead>
              <?php $i=1;?>
              <?php $__currentLoopData = $galery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($value->album->nama); ?></td>
                <td><?php echo e($value->judul); ?></td>
                <td><?php echo e($value->deskripsi); ?></td>
                <td> <img src="/img/<?php echo e($value->gambar); ?>" width="100px" alt=""> </td>
                <td>
                     <a href="#" data-toggle="modal" data-target="#<?php echo e($value->id); ?>">  Edit </a> ||
                     <form action="<?php echo e(url('galeriupdate')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                       <div id="<?php echo e($value->id); ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                          <!-- konten modal-->
                          <div class="modal-content">
                            <!-- heading modal -->
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Form Edit Galeri</h4>
                            </div>
                            <!-- body modal -->
                            <div class="modal-body">
                               <input type="hidden" name="id" class="form-control" value="<?php echo e($value->id); ?>">
                             Album :
                             <select name="album_id" id="album_id" class="form-control">
                                <option value="<?php echo e($value->album->id); ?>"><?php echo e($value->album->nama); ?></option>
                                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($isi->id); ?>"><?php echo e($isi->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>                              
                              Judul : <input type="text" name="judul" class="form-control" value="<?php echo e($value->judul); ?>">
                              Deskripsi : <textarea name="deskripsi" class="form-control"> <?php echo e($value->deskripsi); ?> </textarea>
                              Gambar : <input type="file" name="gambar" class="form-control">
                            </div>
                            <!-- footer modal -->
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>
                              <button type="reset" class="btn btn-default">Cancel</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>