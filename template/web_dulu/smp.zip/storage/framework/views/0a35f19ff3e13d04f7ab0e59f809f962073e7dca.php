<?php $__env->startSection('content'); ?>
<div class="banner">
</div>
<!-- //banner -->
<div class="special-services-1 w3">
	<div class="container">
		<h2 class="title">Kumpulan Berita</h2>

		<div class="special-services-1-grids">
			<?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-3 special-services-1-grid">
				<div class="special-services-1-grid1">
					<img src="<?php echo e($value->gambar); ?>" alt=" " class="img-responsive" width="250px">

				</div>
				<h4>
					<!-- <a href="<?php echo e(url('editnews/')); ?>"><?php echo e($value->nama); ?> </a> -->
					<?php
						echo '<a href="'.url('Detail/'.$value->id).'">'.$value->judul.'</a>';
						
					?>
				</h4>
				<p><?php echo e(strlen($value->isi) > 100 ? substr($value->isi,0,100)  : $value->isi); ?></p>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>