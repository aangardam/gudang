<!DOCTYPE html>
<html>
<head>
	<title>SMP IT - DarurrohmatGURU</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Heaped a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Custom-Stylesheet-Links -->	
	<!-- <link href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>" rel="stylesheet"> -->

	<link rel="stylesheet"	href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>" type="text/css" media="all">
	<link rel="stylesheet"	href="<?php echo e(asset('front/css/style.css')); ?>" type="text/css" media="all">	
	<!-- //Custom-Stylesheet-Links -->	
	<!-- Fonts -->	
	<link rel='stylesheet' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' 	type='text/css'>
	<link rel='stylesheet' href='//fonts.googleapis.com/css?family=Sigmar+One' 			type='text/css'>
	<link rel='stylesheet' href='//fonts.googleapis.com/css?family=Raleway:400,500,600'		type='text/css'>
	<!-- //Fonts -->
	<!-- JavaScript -->
	<script type="text/javascript" src="<?php echo e(asset('front/js/jquery.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/responsiveslides.min.js')); ?>"></script>
	<script>
		$(function () {
			$("#slider1").responsiveSlides({
				auto: true,
				nav: true,
				speed: 1000,
				namespace: "callbacks",
				pager: true,
			});
		});
	</script>
	<script src="<?php echo e(asset('front/js/modernizr.custom.97074.js')); ?>"></script>
	<!-- //JavaScript --><!-- animation-effect -->
	<link href="<?php echo e(asset('front/css/animate.min.css')); ?>" rel="stylesheet"> 
	<script src="<?php echo e(asset('front/js/wow.min.js')); ?>"></script>
	<script>
		new WOW().init();
	</script>
	<!-- //animation-effect -->
	<script src="<?php echo e(asset('front/js/jquery.chocolat.js')); ?>"></script>
		<link rel="stylesheet" href="<?php echo e(asset('front/css/chocolat.css')); ?>" type="text/css" media="screen" charset="utf-8">
		<!--light-box-files -->
		<script type="text/javascript" charset="utf-8">
		$(function() {
			$('.gallery a').Chocolat();
		});
	</script>
</head>
<body>
	<!-- Header -->
	<div class="header">
		<!-- Navbar -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<div class="navbar-header wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo e(url('/')); ?>"></a>
				</div>
				<div id="navbar" class="navbar-collapse collapse">
					<ul class="nav navbar-nav wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
						<li><a href="<?php echo e(url('/')); ?>" class="hover-effect scroll">
							<span>
								<span>BERANDA</span>
								<span>BERANDA</span>
								<span></span>
							</span>
						</a></li>
						<li><a href="<?php echo e(url('about')); ?>" class="hover-effect scroll">
							<span>
								<span>PROFIL</span>
								<span>PROFIL</span>
								<span></span>
							</span>
						</a></li>
						<li><a href="<?php echo e(url('teachers')); ?>" class="hover-effect scroll">
							<span>
								<span>GURU</span>
								<span>GURU</span>
								<span></span>
							</span>
						</a></li>
						<li><a href="<?php echo e(url('gallery')); ?>" class="hover-effect scroll">
							<span>
								<span>GALLERY</span>
								<span>GALLERY</span>
								<span></span>
							</span>
						</a></li>
						<!-- <li><a href="<?php echo e(url('news')); ?>" class="hover-effect scroll">
							<span>
								<span>BERITA</span>
								<span>BERITA</span>
								<span></span>
							</span>
						</a></li> -->
						<li><a href="<?php echo e(url('events')); ?>" class="hover-effect scroll">
							<span>
								<span>KEGIATAN</span>
								<span>KEGIATAN</span>
								<span></span>
							</span>
						</a></li>
						<li><a href="<?php echo e(url('Downloads')); ?>" class="hover-effect scroll">
							<span>
								<span> DOWNLOAD </span>
								<span> DOWNLOAD </span>
								<span></span>
							</span>
						</a></li>
						<li><a href="<?php echo e(url('bantuan')); ?>" class="hover-effect scroll">
							<span>
								<span> BANTUAN </span>
								<span> BANTUAN </span>
								<span></span>
							</span>
						</a></li>
						<li><a href="<?php echo e(url('contact')); ?>" class="hover-effect scroll">
							<span>
								<span>KONTAK</span>
								<span>KONTAK</span>
								<span></span>
							</span>
						</a></li>
					</ul>
				</div>
			</div><!--/.nav-collapse -->
		</nav>
	</div>

	<!-- //Navbar -->
	<?php echo $__env->yieldContent('content'); ?>
	<?php echo $__env->make("section.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>