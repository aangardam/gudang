<?php $__env->startSection('content'); ?>
<div class="banner">
</div>
<!-- //banner -->
<div class="gallery w3agile">
	<div class="container">
		<h1 class="title">Gallery</h1>
		<div class="gallery-grids">
			<section>
				<?php $__currentLoopData = $galery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<ul id="da-thumbs" class="da-thumbs">
					<li>
						<a href="/img/<?php echo e($value->gambar); ?>" rel="title" class="b-link-stripe b-animate-go  thickbox">
							<img src="/img/<?php echo e($value->gambar); ?>" alt="">
							<div style="display: block; left: 0px; top: -100%; transition: all 300ms ease;">

							<h5><?php echo e($value->judul); ?></h5>
								<span><?php echo e($value->deskripsi); ?></span>
							</div>
						</a>
					</li>
				</ul>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</section>
			<script type="text/javascript" src="<?php echo e(asset('front/js/jquery.hoverdir.js')); ?>"></script>	
			<script type="text/javascript">
				$(function() {
					
					$(' #da-thumbs > li ').each( function() { $(this).hoverdir(); } );

				});
			</script>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>