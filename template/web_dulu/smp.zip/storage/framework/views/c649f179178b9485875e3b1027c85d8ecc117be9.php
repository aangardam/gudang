<?php $__env->startSection('content'); ?>
<div class="about wthree">
	<div class="container">
		<div class="col-md-11 about-left wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
			<p><h3><b>A. Zakat Penghasilan</b></h3></p>
			<form action="" method="post" name="Kalkulator" id="Kalkulator">
				<table width="100%" >
					<tr>
						<td colspan="2" bgcolor="yellow" align="center"><b>Perhitungan Zakat Penghasilan</b></td>
					</tr>
					<tr>
						<td colspan="2">
							<p align="justify">
								&nbsp;&nbsp;&nbsp; Penghasilan profesional oleh mayoritas ulama dikategorikan sebagai jenis harta wajib zakat berdasarkan analogi (qiyas)
								atas kepemilikan (syabbah) terhadap kateristik harta zakat yang telah ada, yakni : Model memperoleh harta penghasilan dari profesi mirip dengan panen
								dari hasil pertanian, sehingga harta ini dapat dianalogikan pada zakat pertanian berdasarkan nisab sebesar 653 kg gabah kering giling (setara dengan
								522 kg beras) dengan waktu pengeluaran zakat (haul)nya setiap kali menerima penghasilan (gaji). Model harta yang diterima sebagai penghasilan berupa uang, 
								sehingga jenis harta ini dapat dianalogikan pada zakat harta (simpanan atau kekayaan) berdasarkan zakat yang harus dibayarkan sebesar 2.5%. <br>
								&nbsp;&nbsp;&nbsp;Dengan demikian apabila penghasilan seseorag telah memenuhi ketentuan ambang batas (nisab) wajib zakat, ia berkewajiban menunaikan zakat atas penghasilan.
							</p>
						</td>
					</tr>
					<tr bgcolor="#66FFFF">
						<!-- <th>No</th> -->
						<th>Item/Keterangan</th>
						<th>Jumlah</th>
					</tr>
					<tr>
						<!-- <td>1.</td> -->
						<td>- Penghasilan/Gaji Saya perbulan</td>
						<td>
							Rp. <input name="fa" onkeyup ="calc_simpanan()" value="0" size="12">
						</td>
					</tr>
					<tr>
						<!-- <td>2.</td> -->
						<td>- Penghasilan lain-lain Saya perbulan</td>
						<td>
							Rp. <input name="fb" onkeyup="calc_simpanan()" value="0" size="12">
						</td>
					</tr>
					<tr>
						<!-- <td>3.</td> -->
						<td>- Hutang/Cicilan Saya untuk Kebutuhan Pokok<br>
							<font color="red"> * Kebutuhan sandang, pangan, papan, pendidikan, kesehatan, transportasi premier. </font>
						</td>
						<td>
							Rp. <input name="fc" onkeyup="calc_simpanan()" value="0" size="12">
						</td>
					</tr>
					<tr>
						<!-- <td>1.</td> -->
						<td align="right"><b>Jumlah Penghasilan Saya per Bulan&nbsp;</b></td>
						<td>
							<b> Rp. <input name="ff" style="background: #CDF9FC;border: 0px;" class="fieldzakat" value="0" size="12" readonly="readonly"> </b>
						</td>
					</tr>
					<tr>
						<td>- Harga Beras Saat ini (per kg)</td>
						<td>
							Rp. <input name="beras" value="13000" onkeyup="calc_simpanan()"  value="0" size="12">
						</td>
					</tr>
					<tr>
						<td align="right"><b>Besarnya Nishab Zakat Penghasilan per Bulan&nbsp;</b></td>
						<td>
							Rp. <input style="background: #CDF9FC;border: 0px;" name="nisab" value="0" size="12" readonly="">
						</td>
					</tr>
					<tr>
						<td align="right"><b>Apakah Saya Wajib Membayar Zakat Penghasilan?&nbsp;</b></td>
						<td>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input style="background: #CDF9FC;border: 0px;" name="batas" value="Tidak" readonly=""  size="12">
						</td>
					</tr>
					<tr>
						<td align="right"><b>Jumlah yang Saya Harus Dibayarkan per Bulan&nbsp;</b></td>
						<td>
							Rp. <input style="background: #CDF9FC;border: 0px;" name="jum" value="0"  readonly=""  size="12"> <br>
						</td>
					</tr>
				</table>
				<p><h3><b>B. Zakat Harta (Maal)</b></h3></p>
				<table width="100%">
					<tr bgcolor="#66FFFF">
						<td colspan="2" bgcolor="yellow" align="center"><b>Perhitungan Zakat Maal</b></td>
					</tr>
					<tr>
						<td colspan="2">
							<p align="justify">
								&nbsp;&nbsp;&nbsp; Zakat harta (Maal) adalah sejumlah harta yang wajib dikeluarkan bila telah mencapai batas minimal tertentu (nisab)
								dalam kurun waktu (haul) setiap satu tahun kalender. Untuk harta yang wajib zakat adalah harta yang berjumlah diatas nisab. Nisab zakat harta (Maal) 
								adalah setara dengan 85 gr emas 24 Karat</p>
							</td>
						</tr> 
						<tr bgcolor="#66FFFF">
							<th>Item/Keterangan</th>
							<th>Jumlah</th>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Tabungan/ Giro/ Deposito </td>
							<td>
								Rp. <input name="tabungan" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Logam Mulia (Emas/ Perak) </td>
							<td>
								Rp. <input name="emas" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Surat Berharga
								<br><font color="red">Surat berharga antara lain : Nilai tunai dan Reksadana, Saham, Obligasi, Unit Link dll </font> 
							</td>
							<td>
								Rp. <input name="surat" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Properti 
								<br><font color="red">Catatan : Rumah (Properti) yang digunakan sehari-hari, TIDAK DIKENAKAN ZAKAT </font> 
							</td>
							<td>
								Rp. <input name="properti" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Kendaraan 
								<br><font color="red">Catatan : Kendaraan yang digunakan sehari-hari, TIDAK DIKENAKAN ZAKAT </font> 
							</td>
							<td>
								Rp. <input name="kendaraan" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Koleksi Seni & Barang Antik 
								<br><font color="red">Nilai koleksi dapat ditaksir sendiri, bila dimungkinkan dapat dibantu kurator seni  </font> 
							</td>
							<td>
								Rp. <input name="koleksi" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Stok Barang Dagangan </td>
							<td>
								Rp. <input name="dagangan" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Lainnya </td>
							<td>
								Rp. <input name="lainnya" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td>- Harta dalam bentuk Piutang Lancar </td>
							<td>
								Rp. <input name="hutang" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td align="right"><b> Jumlah Harta &nbsp;</b></td>
							<td>
								<b> Rp. <input style="background: #CDF9FC;border: 0px;" name="harta" class="fieldzakat" value="0" size="12" readonly="readonly"> </b>
							</td>
						</tr>
						<tr>
							<td>- Hutang Jatuh Tempo Saat Membayar Kewajiban Zakat
								<br><font color="red">Contoh bagi pedagang yang harus melunasi cicilan hutang atas barang yang diperdagangkan </font> 
							</td>
							<td>
								Rp. <input name="tempo" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>
						<tr>
							<td align="right"><b> Jumlah Harta Yang Dihitung Zakatnya &nbsp;</b></td>
							<td>
								<b> Rp. <input style="background: #CDF9FC;border: 0px;" name="zakatharta" class="fieldzakat" value="0" size="12" readonly="readonly"> </b>
							</td>
						</tr>
						<tr>
							<td>- Harga Emas saat ini (dalam gram)
								<br><font color="red">Harga mas murni tahun 2017 sekitar <b>Rp. 535.500</b> </font> 
							</td>
							<td>
								Rp. <input name="hargamas" value="535500" onkeyup="calc_simpanan()"  value="0" size="12">
							</td>
						</tr>

						<tr>
							<td align="right"><b> Besarnya Nisab Zakat Maal per Tahun &nbsp;</b></td>
							<td>
								<b> Rp. <input style="background: #CDF9FC;border: 0px;" name="nisobpertaun" class="fieldzakat" value="0" size="12" readonly="readonly"> </b>
							</td>
						</tr>
						<tr>
							<td align="right"><b> Apakah Saya Wajib Membayar Zakat Maal ? &nbsp;</b></td>
							<td>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input style="background: #CDF9FC;border: 0px;" name="wajibbayar" class="fieldzakat" value="Tidak" size="12" readonly="readonly"> </b>
							</td>
						</tr>
						<tr>
							<td align="right"><b> Jumlah yang Saya Harus Dibayarkan per Tahun &nbsp;</b></td>
							<td>
								<b> Rp. <input style="background: #CDF9FC;border: 0px;" name="jml" class="fieldzakat" value="0" size="12" readonly="readonly"> </b>
							</td>
						</tr>
						<tr>
							<td align="right"><b> Jumlah Bila Saya Bayarkan per Bulan &nbsp;</b></td>
							<td>
								<b> Rp. <input style="background: #CDF9FC;border: 0px;" name="jml2" class="fieldzakat" value="0" size="12" readonly="readonly"> </b>
							</td>
						</tr>
					</table>
					<p><h3><b>C. Resume Penghitungan Zakat</b></h3></p>
					<table width="100%" >
						<tr bgcolor="#66FFFF">
							<th>Item/Keterangan</th>
							<th>Jumlah</th>
						</tr>
						<tr>
							<td align="right"><b> Zakat Penghasilan per Bulan </td>
							<td>
								Rp. <input style="background: #CDF9FC;border: 0px;" name="penghasilanbulan" value="0"  readonly=""  size="12">
							</td>
						</tr>
						<tr>
							<td align="right"><b> Zakat Maal yang dibayarkan per Bulan </td>
							<td>
								Rp. <input style="background: #CDF9FC;border: 0px;" name="maalbulan" class="fieldzakat" value="0" size="12" readonly="readonly"> 
							</td>
						</tr>
						<tr>
							<td align="right"><b> Total Pembayaran Zakat Saya per Bulan </b></td>
							<td>
								Rp. <input style="background: #CDF9FC;border: 0px;" name="total" class="fieldzakat" value="0" size="12" readonly="readonly"> 
							</td>
						</tr>
					</table>
				</form>
<script language="JavaScript" type="text/javascript">
	function calc_simpanan()
	{
		/*Zakat Penghasilan*/
		document.Kalkulator.ff.value = 
		parseInt(document.Kalkulator.fa.value) +
		parseInt(document.Kalkulator.fb.value) -
		parseInt(document.Kalkulator.fc.value);

		var zakat = document.Kalkulator.ff.value;

		document.Kalkulator.nisab.value =
		parseInt(document.Kalkulator.beras.value) *522;

		var nishab = document.Kalkulator.nisab.value;
		nishab = parseInt(nishab);
		zakat = parseInt(zakat);

		if(zakat < nishab){
			document.Kalkulator.batas.value = "Tidak";
			document.Kalkulator.jum.value = 0;
		}else{
			document.Kalkulator.batas.value = "Ya";
			document.Kalkulator.jum.value = 0.025 * zakat;
		}

		/*Zakat Harta*/
		document.Kalkulator.harta.value =
		parseInt(document.Kalkulator.tabungan.value) +
		parseInt(document.Kalkulator.emas.value)+
		parseInt(document.Kalkulator.surat.value)+
		parseInt(document.Kalkulator.properti.value)+
		parseInt(document.Kalkulator.kendaraan.value)+
		parseInt(document.Kalkulator.koleksi.value)+
		parseInt(document.Kalkulator.dagangan.value)+
		parseInt(document.Kalkulator.lainnya.value)+
		parseInt(document.Kalkulator.hutang.value);

		document.Kalkulator.zakatharta.value =
		parseInt(document.Kalkulator.harta.value) -
		parseInt(document.Kalkulator.tempo.value);

		document.Kalkulator.nisobpertaun.value =
		parseInt(document.Kalkulator.hargamas.value) *85;

		var nisobpertaun = document.Kalkulator.nisobpertaun.value;
		nisobpertaun = parseInt(nisobpertaun);
		var zakatharta =  document.Kalkulator.zakatharta.value;
		zakatharta = parseInt(zakatharta);

		if(zakatharta < nisobpertaun){
			document.Kalkulator.wajibbayar.value = "Tidak";
			document.Kalkulator.jml.value = 0;
			document.Kalkulator.jml2.value = 0;
		}else{
			document.Kalkulator.wajibbayar.value = "Ya";
			document.Kalkulator.jml.value = 0.025 * zakatharta;
			document.Kalkulator.jml2.value = 
			parseInt(document.Kalkulator.jml.value) / 12;
		}
		document.Kalkulator.penghasilanbulan.value = document.Kalkulator.jum.value;
		document.Kalkulator.maalbulan.value = document.Kalkulator.jml.value/12;
		document.Kalkulator.total.value =
		parseInt(document.Kalkulator.penghasilanbulan.value) +
		parseInt(document.Kalkulator.maalbulan.value);

	}

</script>
</div>
<div class="clearfix"> </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>