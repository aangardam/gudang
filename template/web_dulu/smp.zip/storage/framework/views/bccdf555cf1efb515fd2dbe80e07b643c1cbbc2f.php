<section class="menu-section">
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="navbar-collapse collapse ">
                <ul id="menu-top" class="nav navbar-nav navbar-right">
                    <!-- <li><a class="menu-top-active" href="index.html">Dashboard</a></li>
                    <li><a href="ui.html">UI Elements</a></li>
                    <li><a href="table.html">Data Tables</a></li>
                    <li><a href="forms.html">Forms</a></li>
                    <li><a href="login.html">Login Page</a></li> -->
                    <li><a href="<?php echo e(url('/home')); ?>">Beranda</a></li>
                    <li><a href="<?php echo e(url('slide')); ?>">Side</a></li>
                    <li><a href="<?php echo e(url('guru')); ?>">Guru</a></li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Galari
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(url('album')); ?>">album</a></li>
                            <li><a href="<?php echo e(url('galeri')); ?>"> Galari </a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('berita')); ?>">Berita</a></li>
                    <!-- <li><a href="<?php echo e(url('comment')); ?>">Komen</a></li> -->
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Komen
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(url('comment')); ?>">Komen Berita</a></li>
                            <li><a href="<?php echo e(url('comment2')); ?>"> Komen Kegiatan </a></li>
                        </ul>
                    </li>


                    <li><a href="<?php echo e(url('kegiatan')); ?>">Even</a></li>
                    <li><a href="<?php echo e(url('download')); ?>">Download</a></li>
                    <li><a href="<?php echo e(url('kontak')); ?>">Kontak</a></li>
                   <!--  <li><a href="<?php echo e(url('user')); ?>">Users</a></li> -->
                    <li>
                        <a href="<?php echo e(url('/logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                        Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>


                    <!-- <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Galari
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(url('we')); ?>"> Album </a></li>
                            <li><a href="<?php echo e(url('jf')); ?>"> Galari </a></li>
                        </ul>
                    </li> -->
                    
                </ul>
            </div>
        </div>
    </div>
</div>
</section>