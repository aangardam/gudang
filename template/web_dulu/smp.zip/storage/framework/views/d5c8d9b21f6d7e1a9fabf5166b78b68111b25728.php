<?php $__env->startSection('content'); ?>
<!-- banner -->
<div class="banner">
</div>
<!-- //banner -->
<div class="typo agileits-1">
	<div class="container">	
		<div class="page-header">
			<h3 class="bars">Download File</h3>
		</div>
		<!-- <p>Enable a hover state on table rows within a <code>&lt;tbody&gt;</code>.</p> -->
		<p><hr></p>
		<div class="bs-docs-example">
			<table class="table table-hover">
				<thead>
					<?php $__currentLoopData = $download; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($key+1); ?></td>
							<td> <a href="<?php echo e($value->file); ?>"><?php echo e($value->judul); ?></a></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</thead>
			</table>
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>