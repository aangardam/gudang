<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Kegiatan</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Kegiatan </a>
            </td>
            <!-- Modal -->
            <form action="<?php echo e(url('eventstore')); ?>" method="post" enctype="multipart/form-data">
           <?php echo e(csrf_field()); ?>

            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah Kegiatan</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Nama : 
                    <input type="text" name="nama" id="nama" class="form-control">
                    Tanggal :
                    <input type="date" name="tanggal" id="tanggal" class="form-control">
                    Deskripsi :
                    <textarea name="deskripsi" class="form-control"></textarea>
                    Gambar :
                    <input type="file" name="gambar" class="form-control">
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </tr>
        </table>
        </div>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Tanggal</th>
                  <th>Deskripsi</th>
                  <th>Gambar</th>
                  <th>Update</th>
                </tr>
              </thead>
              <?php $i=1;?>
              <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($value->nama); ?></td>
                <td><?php echo e($value->tanggal); ?></td>
                <td><?php echo e($value->deskripsi); ?></td>
                <td> <img src="imgevents/<?php echo e($value->gambar); ?>" width="100px" alt=""> </td>
                <td>
                     <a href="#" data-toggle="modal" data-target="#<?php echo e($value->id); ?>">  Edit </a> ||
                     <form action="<?php echo e(url('eventupdate')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                       <div id="<?php echo e($value->id); ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                          <!-- konten modal-->
                          <div class="modal-content">
                            <!-- heading modal -->
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Form Edit Kegiatan</h4>
                            </div>
                            <!-- body modal -->
                            <div class="modal-body">

                            <input type="hidden" name="id" id="id" class="form-control" value="<?php echo e($value->id); ?>">

                             Nama : 
                             <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e($value->nama); ?>">
                             Tanggal :
                             <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?php echo e($value->tanggal); ?>">
                             Deskripsi :
                             <textarea name="deskripsi" class="form-control"><?php echo e($value->deskripsi); ?></textarea>
                             Gambar :
                             <input type="file" name="gambar" class="form-control">
                           </div>
                            <!-- footer modal -->
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>
                              <button type="reset" class="btn btn-default">Cancel</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                    <?php
                         echo '<a href="'.url('evetsdestroy/'.$value->id).'" onclick="return confirm(\'Yakin mau hapus data ini?\')" > Hapus </a>';
                      ?>
                </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>