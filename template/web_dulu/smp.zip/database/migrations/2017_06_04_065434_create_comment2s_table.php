<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateComment2sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comment2s', function (Blueprint $table) {
             $table->increments('id');
            $table->integer('evnets_id')->unsigned();
            $table->string('nama');
            $table->string('email');
            $table->string('hp');
            $table->text('isi');
            $table->timestamps();


        $table->foreign('evnets_id')->references('id')->on('events')
             ->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comment2s');
    }
}
