@extends('layouts.admin')
@section('content')
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Kegiatan</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Kegiatan </a>
            </td>
            <!-- Modal -->
            <form action="{{ url('eventstore') }}" method="post" enctype="multipart/form-data">
           {{ csrf_field() }}
            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah Kegiatan</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Nama : 
                    <input type="text" name="nama" id="nama" class="form-control">
                    Tanggal :
                    <input type="date" name="tanggal" id="tanggal" class="form-control">
                    Deskripsi :
                    <textarea name="deskripsi" class="form-control"></textarea>
                    Gambar :
                    <input type="file" name="gambar" class="form-control">
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </tr>
        </table>
        </div>
        @if(Session::has('message'))
        <div class="alert alert-success">
          {{ Session::get('message') }}
        </div>
        @endif
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Tanggal</th>
                  <th>Deskripsi</th>
                  <th>Gambar</th>
                  <th>Update</th>
                </tr>
              </thead>
              <?php $i=1;?>
              @foreach($event as $key => $value)
                <td>{{ $i++ }}</td>
                <td>{{ $value->nama }}</td>
                <td>{{ $value->tanggal }}</td>
                <td>{{ $value->deskripsi }}</td>
                <td> <img src="imgevents/{{ $value->gambar }}" width="100px" alt=""> </td>
                <td>
                     <a href="#" data-toggle="modal" data-target="#{{$value->id}}">  Edit </a> ||
                     <form action="{{ url('eventupdate') }}" method="post" enctype="multipart/form-data">
                      {{ csrf_field() }}
                       <div id="{{$value->id}}" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                          <!-- konten modal-->
                          <div class="modal-content">
                            <!-- heading modal -->
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Form Edit Kegiatan</h4>
                            </div>
                            <!-- body modal -->
                            <div class="modal-body">

                            <input type="hidden" name="id" id="id" class="form-control" value="{{$value->id}}">

                             Nama : 
                             <input type="text" name="nama" id="nama" class="form-control" value="{{$value->nama}}">
                             Tanggal :
                             <input type="date" name="tanggal" id="tanggal" class="form-control" value="{{$value->tanggal}}">
                             Deskripsi :
                             <textarea name="deskripsi" class="form-control">{{$value->deskripsi}}</textarea>
                             Gambar :
                             <input type="file" name="gambar" class="form-control">
                           </div>
                            <!-- footer modal -->
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>
                              <button type="reset" class="btn btn-default">Cancel</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                    <?php
                         echo '<a href="'.url('evetsdestroy/'.$value->id).'" onclick="return confirm(\'Yakin mau hapus data ini?\')" > Hapus </a>';
                      ?>
                </td>
              @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
@endsection