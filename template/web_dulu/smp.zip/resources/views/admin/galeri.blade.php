@extends('layouts.admin')
@section('content')
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Galeri</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Galeri </a>
            </td>
            <!-- Modal -->
            <form action="{{ url('galeristore') }}" method="post" enctype="multipart/form-data">
           {{ csrf_field() }}
            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah Galeri</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Album :
                          <select name="album_id" class="form-control">
                            @foreach($album as $key=>$value)
                              <option value="{{ $value->id}}">{{ $value->nama }}</option>
                            @endforeach
                          </select>
                    Judul : <input type="text" name="judul" class="form-control">
                    Deskripsi : <textarea name="deskripsi" class="form-control"></textarea>
                    Gambar : <input type="file" name="gambar" class="form-control">
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </tr>
        </table>
        </div>
        @if(Session::has('message'))
        <div class="alert alert-success">
          {{ Session::get('message') }}
        </div>
        @endif
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Album</th>
                  <th>Judul</th>
                  <th>Deskripsi</th>
                  <th>Gambar</th>
                  <th>Update</th>
                </tr>
              </thead>
              <?php $i=1;?>
              @foreach($galery as $key => $value)
                <td>{{ $i++ }}</td>
                <td>{{ $value->album->nama }}</td>
                <td>{{ $value->judul }}</td>
                <td>{{ $value->deskripsi }}</td>
                <td> <img src="/img/{{ $value->gambar }}" width="100px" alt=""> </td>
                <td>
                     <a href="#" data-toggle="modal" data-target="#{{$value->id}}">  Edit </a> ||
                     <form action="{{ url('galeriupdate') }}" method="post" enctype="multipart/form-data">
                      {{ csrf_field() }}
                       <div id="{{$value->id}}" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                          <!-- konten modal-->
                          <div class="modal-content">
                            <!-- heading modal -->
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Form Edit Galeri</h4>
                            </div>
                            <!-- body modal -->
                            <div class="modal-body">
                               <input type="hidden" name="id" class="form-control" value="{{$value->id}}">
                             Album :
                             <select name="album_id" id="album_id" class="form-control">
                                <option value="{{ $value->album->id }}">{{$value->album->nama}}</option>
                                @foreach($album as $key=>$isi)
                                  <option value="{{ $isi->id}}">{{ $isi->nama }}</option>
                                @endforeach
                             </select>                              
                              Judul : <input type="text" name="judul" class="form-control" value="{{$value->judul}}">
                              Deskripsi : <textarea name="deskripsi" class="form-control"> {{ $value->deskripsi }} </textarea>
                              Gambar : <input type="file" name="gambar" class="form-control">
                            </div>
                            <!-- footer modal -->
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>
                              <button type="reset" class="btn btn-default">Cancel</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                </td>
              @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
@endsection