@extends('layouts.admin')
@section('content')
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Pesan</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
        </div>
        @if(Session::has('message'))
        <div class="alert alert-success">
          {{ Session::get('message') }}
        </div>
        @endif
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Pesan</th>
                  <th>Update</th>
                </tr>
              </thead>
              <?php $i=1;?>
              @foreach($Contacts as $key => $value)
                <tr>
                  <td>{{ $i++ }}</td>
                  <td>{{ $value->nama }}</td>
                  <td>{{ $value->email }}</td>
                  <td>{{ $value->pesan }}</td>
                  <td>
                    <?php
                         echo '<a href="'.url('Contactsdestroy/'.$value->id).'" onclick="return confirm(\'Yakin mau hapus data ini?\')" > Hapus </a>';
                      ?>
                  </td>
                </tr>
              @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
@endsection