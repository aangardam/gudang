@extends('layouts.admin')
@section('content')
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Jajaran Staf dan Guru</h1>
      </div>
    </div>

    <div class="row">
      @if(Session::has('message'))
      <div class="alert alert-success">
          {{ Session::get('message') }}
      </div>
      @endif
      <div class="col-md-12">
        <!--    Bordered Table  -->
        <div class="panel panel-default">
          <div class="panel-heading">
            <!-- Bordered Table -->
            <table width="100%">
              <tr>
                <td width="50%" align="left">
                  &nbsp;
                </td>
                <td width="50%" align="right">
                 <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#tambah"> + Tambah Staf </a>
               </td>
               <form action="{{url('gurustore')}}" method="post" enctype="multipart/form-data">
                 {{ csrf_field() }}
                 <div id="tambah" class="modal fade" role="dialog">
                  <div class="modal-dialog">
                    <!-- konten modal-->
                    <div class="modal-content">
                      <!-- heading modal -->
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Form Tambah Guru</h4>
                      </div>
                      <!-- body modal -->
                      <div class="modal-body">
                        Nama  : <input type="text" name="nama" class="form-control">
                        Jabatan :
                        <select name="jabatan" class="form-control">
                          <option>Ketua Yayasan</option>
                          <option>Kepala Sekolah</option>
                          <option>Wakil Kepala Sekolah</option>
                          <option>Kesiswaan</option>
                          <option>Guru</option>
                          <option>TU</option>
                        </select>
                        Mengajar :<textarea name="mengajar" class="form-control"></textarea>
                        Pendidikan : <input type="text" name="pendidikan" class="form-control">
                        Foto : <input type="file" name="foto" class="form-control">
                      </div>
                      <!-- footer modal -->
                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="reset" class="btn btn-default">Cancel</button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
             </tr>
           </table>
          </div>
          <!-- /.panel-heading -->
          <div class="panel-body">

            <div class="table-responsive table-bordered"> 
              <!--  <table class="table table-striped"> -->
              <table class="table">
               <thead>
                <tr>
                  <th> No</th>
                  <th> Nama </th>
                  <th> Jabatan </th>
                  <th> Pendidikan </th>
                  <th> Mengajar </th>
                  <th>Foto</th>
                  <th> Update </th>
                </tr>
              </thead>
              <tbody>
                <?php $i=1;?>
                @foreach($Guru as $key=>$value)
                  <tr>
                    <td>{{ $i++ }}</td>
                    <td>{{ $value->nama }}</td>
                    <td>{{$value->jabatan }}</td>
                    <td>{{$value->pendidikan }}</td>
                    <td>{{nl2br($value->mengajar) }}</td>
                    <td> <img src="/img/{{ $value->foto }}" width="100px" alt=""> </td>
                    <td>
                      <a href="#" data-toggle="modal" data-target="#{{$value->id}}">Edit</a> ||
                      <form action="{{url('guruupdate')}}" method="post" enctype="multipart/form-data">
                       {{ csrf_field() }}
                       <div id="{{$value->id}}" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                          <!-- konten modal-->
                          <div class="modal-content">
                            <!-- heading modal -->
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Form Edit Guru</h4>
                            </div>
                            <!-- body modal -->
                            <div class="modal-body">
                              Nama  : <input type="text" name="nama" class="form-control" value="{{$value->nama}}">
                              <input type="hidden" name="id" class="form-control" value="{{$value->id}}">
                              Jabatan :
                              <select name="jabatan" class="form-control">
                                <option>{{$value->jabatan}}</option>
                                <option>Ketua Yayasan</option>
                                <option>Kepala Sekolah</option>
                                <option>Wakil Kepala Sekolah</option>
                                <option>Kesiswaan</option>
                                <option>Guru</option>
                                <option>TU</option>
                              </select>
                              Mengajar :<textarea name="mengajar" class="form-control">{{$value->mengajar}}</textarea>
                              Pendidikan : <input type="text" name="pendidikan" class="form-control" value="{{$value->pendidikan}}">
                              Foto : <input type="file" name="foto" class="form-control">
                            </div>
                            <!-- footer modal -->
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>
                              <button type="reset" class="btn btn-default">Cancel</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                    <?php
                       echo '<a href="'.url('gurudestroy/'.$value->id).'" onclick="return confirm(\'Yakin mau hapus data ini?\')" > Hapus </a>';
                    ?>
                  </td>
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!--  End  Bordered Table  -->
    </div>
    </div>
</div>

</div>
</div>
@endsection