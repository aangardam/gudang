@extends('layouts.admin')
@section('content')
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Berita</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Berita </a>
            </td>
            <!-- Modal -->
            <form action="{{ url('berita') }}" method="post" enctype="multipart/form-data">
           {{ csrf_field() }}
            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah Berita</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Judul : <input type="text" name="judul" class="form-control">
                    Penulis : <input type="text" name="penulis" class="form-control">
                    Isi : <textarea name="isi" class="form-control" rows="10"></textarea>
                    Gambar : <input type="file" name="gambar" class="form-control">
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </tr>
        </table>
        </div>
        @if(Session::has('message'))
        <div class="alert alert-success">
          {{ Session::get('message') }}
        </div>
        @endif
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Judul</th>
                  <th>Tanggal</th>
                  <th>Isi</th>
                  <th>Penulis</th>
                  <th>Gambar</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>
              @foreach($berita as $key=>$value)
                <tr>
                  <td>{{ $key+1 }}</td>
                  <td>{{ $value->judul }}</td>
                  <td>{{ $value->created_at }}</td>
                  <td>
                    {{ strlen($value->isi) > 100 ? substr($value->isi,0,100) . ". . .Readmore" : $value->isi }}
                  </td>
                  <td>{{ $value->penulis}}</td>
                  <td> <img src="{{$value->gambar}}" alt="" width="150px" /></td>
                  <td>
                    <a href="#" data-toggle="modal" data-target="#{{$value->id}}">  Edit </a>
                    <form action="{{ url('berita/' . $value->id) }}" method="post" enctype="multipart/form-data">
                     {{ csrf_field() }}
                     <input type="hidden" name="_method" value="put">
                     <div id="{{$value->id}}" class="modal fade" role="dialog">
                      <div class="modal-dialog">
                        <!-- konten modal-->
                        <div class="modal-content">
                          <!-- heading modal -->
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Form Edit Berita</h4>
                          </div>
                          <!-- body modal -->
                          <div class="modal-body">
                            Judul : <input type="text" name="judul" class="form-control" value="{{$value->judul}}">

                            <input type="hidden" name="id" class="form-control" value="{{$value->id}}">

                            Penulis : <input type="text" name="penulis" class="form-control" value="{{$value->penulis}}">
                            Isi : <textarea name="isi" class="form-control" rows="10">{{ $value->isi}}</textarea>
                            Gambar : <input type="file" name="gambar" class="form-control">
                          </div>
                          <!-- footer modal -->
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <button type="reset" class="btn btn-default">Cancel</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                  <!-- <a href="{{ url('berita/' . $value->id) }}" onclick="return confirm('Yakin mau hapus data ini?')"> Hapus </a> -->
                  <form method="post" action="{{ url('berita/' . $value->id) }}">
                    <input type="hidden" name="_method" value="DELETE">
                    {{ csrf_field() }}
                      <!-- <a href="{{url('comment/'.$value->id)}}" onclick="return confirm('Yakin mau hapus data ini?')"> Hapus </a>   -->
                      <input type="submit" value="delete" onclick="return confirm('Yakin mau hapus data ini?')" >
                    </form>
                  </td> 
                  
                </tr>
              @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
@endsection