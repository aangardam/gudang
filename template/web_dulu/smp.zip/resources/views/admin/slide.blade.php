@extends('layouts.admin')
@section('content')
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Galeri</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
         <table width="100%">
           <tr>
             <td align="right">
              <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Slide Show </a>
            </td>
            <!-- Modal -->
            <form action="{{ url('slide') }}" method="post" enctype="multipart/form-data">
             {{ csrf_field() }}
             <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Tambah Slide Show</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                    Judul : <input type="text" name="judul" class="form-control">
                    Gambar : <input type="file" name="gambar" class="form-control">
                  </div>
                  <!-- footer modal -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </tr>
      </table>
    </div>
    @if(Session::has('message'))
    <div class="alert alert-success">
      {{ Session::get('message') }}
    </div>
    @endif
    <div class="panel-body">
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>No</th>
              <th>Judul</th>
              <th>Gambar</th>
              <th>Status</th>
              <th>Update</th>
            </tr>
          </thead>
          <?php $i=1;?>
          @foreach($slide as $key => $value)
          <tr>
            <td>{{ $i++ }}</td>
            <td>{{ $value->judul }}</td>
            <td> <img src="{{ $value->gambar }}" width="100px" alt=""> </td>
            <td>
              @if($value->status=='Akrif')
              Aktif
              @else{
              Tidak Aktif
            }
            @endif
          </td>
          <td>
           <a href="#" data-toggle="modal" data-target="#{{$value->id}}">  Edit </a> ||
           <form action="{{ url('slide/' . $value->id) }}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <input type="hidden" name="_method" value="put">
            <div id="{{$value->id}}" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                  <!-- heading modal -->
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Form Edit Slide Show</h4>
                  </div>
                  <!-- body modal -->
                  <div class="modal-body">
                   <input type="hidden" name="id" class="form-control" value="{{$value->id}}">                             
                   Judul : <input type="text" name="judul" class="form-control" value="{{$value->judul}}">
                   Status :
                   <select name="status" class="form-control">
                     @if($value->status=='Akrif')
                       <option value="Akrif"> Aktif </option>
                       <option value="Tidak"> Tidak Aktif </option>
                     @else{
                       <option value="Tidak"> Tidak Aktif </option>
                       <option value="Akrif"> Aktif </option>
                      }
                     @endif
                  </select>
                 Gambar : <input type="file" name="gambar" class="form-control">
                  </div>
               <!-- footer modal -->
               <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="reset" class="btn btn-default">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </td>
  </tr>
  @endforeach
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
@endsection