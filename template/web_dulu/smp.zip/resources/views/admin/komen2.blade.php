@extends('layouts.admin')
@section('content')
<div class="content-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="page-head-line">Data Komen Kegiatan</h1>
      </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
        <!-- test -->
        </div>
        @if(Session::has('message'))
        <div class="alert alert-success">
          {{ Session::get('message') }}
        </div>
        @endif
        <div class="panel-body">
          <div class="table-responsive">
          @foreach($event as $key=>$value)
          <table width="98%">
            <tr>
              <td width="70%" align="left"><b> {{$value->nama}} </b></td>
              <td align="right">
                <a href="#" data-toggle="modal" data-target="#myModal">  Tambah Komen </a>
                <form action="{{ url('comment2') }}" method="post" enctype="multipart/form-data">
                 {{ csrf_field() }}
                 <input type="hidden" name="evnets_id" class="form-control" value="{{$value->id}}" readonly="">
                 <input type="hidden" name="hp" class="form-control" value="-" readonly="">
                 <input type="hidden" name="email" class="form-control" value="-" readonly="">
                 <input type="hidden" name="nama" class="form-control" value="admin" readonly="">

                 <div id="myModal" class="modal fade" role="dialog">
<!-- evnets_id -->
                  <div class="modal-dialog">
                    <!-- konten modal-->
                    <div class="modal-content">
                      <!-- heading modal -->
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Form Tambah Komentar</h4>
                      </div>
                      <!-- body modal -->
                      <div class="modal-body">
                        Nama Kegiatan<input type="text" name="judul" class="form-control" value="{{$value->nama}}" readonly="">

                        Komentar <textarea name="isi" class="form-control"></textarea>
                      </div>
                      <!-- footer modal -->
                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="reset" class="btn btn-default">Cancel</button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
              </td>
            </tr>
            <tr>
              <td colspan="2"><hr></td>
            </tr>
          </table>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>HP</th>
                  <th>Tanggal</th>
                  <th>Isi</th>
                  <th>Update</th>
                </tr>
              </thead>
              <tbody>
                @foreach($value->comment2 as $key => $value1)
                <tr>
                  <td>{{ $key+1 }}</td>
                  <td>{{ $value1->nama }}</td>
                  <td>{{ $value1->email }}</td>
                  <td>{{ $value1->hp }}</td>
                  <td>{{ $value1->created_at }}</td>
                  <td>{{ $value1->isi}}</td>
                  <td>
                    <form method="post" action="{{ url('comment2/' . $value1->id) }}">
                    <input type="hidden" name="_method" value="DELETE">
                    {{ csrf_field() }}
                      <!-- <a href="{{url('comment/'.$value->id)}}" onclick="return confirm('Yakin mau hapus data ini?')"> Hapus </a>   -->
                      <input type="submit" value="delete" onclick="return confirm('Yakin mau hapus data ini?')" >
                    </form>
                    
                  </td> 
                </tr>
                @endforeach
              </tbody>
            </table>
            @endforeach
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
@endsection