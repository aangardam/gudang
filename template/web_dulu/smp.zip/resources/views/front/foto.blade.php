@extends('layouts.front')
@section('content')
<div class="banner">
</div>
<!-- //banner -->
<div class="gallery w3agile">
	<div class="container">
		<h1 class="title">Gallery</h1>
		<div class="gallery-grids">
			<section>
				@foreach($galery as $key => $value)
				<ul id="da-thumbs" class="da-thumbs">
					<li>
						<a href="/img/{{ $value->gambar }}" rel="title" class="b-link-stripe b-animate-go  thickbox">
							<img src="/img/{{ $value->gambar }}" alt="">
							<div style="display: block; left: 0px; top: -100%; transition: all 300ms ease;">

							<h5>{{$value->judul}}</h5>
								<span>{{$value->deskripsi}}</span>
							</div>
						</a>
					</li>
				</ul>
				@endforeach
			</section>
			<script type="text/javascript" src="{{asset('front/js/jquery.hoverdir.js')}}"></script>	
			<script type="text/javascript">
				$(function() {
					
					$(' #da-thumbs > li ').each( function() { $(this).hoverdir(); } );

				});
			</script>
		</div>
	</div>
</div>
@endsection