@extends('layouts.front')
@section('content')
<!-- banner -->
<div class="banner">
</div>
<!-- //banner -->
<div class="typo agileits-1">
	<div class="container">	
		<div class="page-header">
			<h3 class="bars">Staff Pengajar SMP IT Darurrohmat</h3>
		</div>
		<!-- <p>Enable a hover state on table rows within a <code>&lt;tbody&gt;</code>.</p> -->
		<p><hr></p>
		<div class="bs-docs-example">
			<table class="table table-hover">
				<thead>
					<tr>
						<th>No</th>
						<th>Nama</th>
						<th>Jabatan</th>
						<th>Pendidikan Terakhir</th>
						<th>Foto</th>
					</tr>
				</thead>
				<tbody>
                <?php $i=1;?>
                @foreach($Guru as $key=>$value)
                  <tr>
                    <td>{{ $i++ }}</td>
                    <td>{{ $value->nama }}</td>
                    <td>{{$value->jabatan }}</td>
                    <td>{{$value->pendidikan }}</td>
                    <td> <img src="/img/{{ $value->foto }}" width="100px" alt=""> </td>
                  </tr>
                @endforeach
              </tbody>
			</table>
		</div>
	</div>
</div>
@endsection