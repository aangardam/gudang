@extends('layouts.front')
@section('content')
<!-- Slider -->
<div class="slider">
	<ul class="rslides" id="slider1">
		<!-- <li>
			<img src="{{asset('front/images/gedung.jpg')}}" alt="Wanderer">
			<div class="caption">
				<h3>Bangunan SMP IT Darurrohmat</h3>
			</div>
		</li> -->
		@foreach($slide as $key => $value)
		<li>
			<img src="{{ $value->gambar }}" >
			<div class="caption">
				<h3>{{ $value->judul }}</h3>
			</div>
		</li>
		@endforeach
		<!-- <li>
			<img src="{{asset('front/images/angklung.jpg')}}" alt="Wanderer">
			<div class="caption">
				<h3>Team Angklung SMP IT Darurrohmat</h3>
			</div>
		</li>
		<li>
			<img src="{{asset('front/images/slide-1.jpg')}}" alt="Wanderer">
			<div class="caption">
				<h3>Lorem Ipsum available, but the majority have suffered alteration in some form</h3>
			</div>
		</li>
		<li>
			<img src="{{asset('front/images/slide-2.jpg')}}" alt="Wanderer">

			<div class="caption">
				<h3>Lorem Ipsum available, but the majority have suffered alteration in some form</h3>
			</div>
		</li>
		<li>
			<img src="{{asset('front/images/slide-1.jpg')}}" alt="Wanderer">
			<div class="caption">
				<h3>Lorem Ipsum available, but the majority have suffered alteration in some form</h3>
			</div>
		</li> -->
	</ul>
</div>
<!-- //Slider -->
<!-- about -->
<div class="about wthree">
	<div class="container">
		<!-- <div class="col-md-6 about-right wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
			<div class="content-item">

				<div class="overlay"></div>

				<div class="corner-overlay-content">Info</div>

				<div class="overlay-content">
					<h2>Voluptate Velit Esse</h2>
					<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</p>
				</div>
			</div>
		</div> -->
		<div class="col-md-11 about-left wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
			<h3>SMP IT DARURROHMAT </h3>

			<p align="justify">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SMP IT ( Islam Terpadu ) Darurrohmat merupakan salah satu lembaga formal di bawah naungan Yayasan Darurrohmat Assakhi dan merupakan SMP pertama dan satu-satunya yang berada di daerah Desa Parakan Kecamatan Leuwimunding, Kabupaten Majalengka. SMP IT ( Islam Terpadu ) Darurrohmat ini beralamat lengkap di Kampung sugih RT 04 RW 07 blok Jum'at Desa Parakan Kecamatan Leuwimunding Kabupaten Majalengka.</p>
				<p align="justify">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SMP ini sedikit berbeda dengan SMP-SMP lainnya yakni lebih mengutamakan ilmu-ilmu agamanya atau bisa dikatakan bahwa di SMP ini pelajaran agamanya diperbanyak atau di tambah jam belajarnya, sehingga secara sekilas SMP ini mirip dengan MTS namun apabila MTS mengacu pada DEPAG (Departemen Agama) sedangkan SMP ini tetap mengacu ke DINAS. 
				</p>
				<p align="justify">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Selain pelajaran agamanya di tambah di SMP ini juga menerapkan sedikit ilmu yang berjalan di pesantren Darurrohmat yakni mengkaji kitab kuning (melogat) sehingga siswa dan siswinya juga belajar yang namanya mengkaji kitab kuning yang di terapkan di Pondok Pesantren Darurrohmat, yang mengajarnya juga langsung di ambil dari pondok pesantren tersebut sehingga kualitasnya tidak di ragukan lagi. Selain itu juga guru-guru yang mengajar di pelajaran-pelajaran lainnya, baik itu ilmu agama maupun ilmu-ilmu lainnya tidak diragukan lagi mereka guru-guru yang sudah handal dalam mengajar dan mendidik bahkan sebagian sudah ada yang menyandang gelar magister (Lulusan S2)
				</p>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>

@endsection