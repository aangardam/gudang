@extends('layouts.front')
@section('content')
<div class="banner">
</div>
<!-- //banner -->
<div class="special-services-1 w3">
	<div class="container">
		<h2 class="title">Kumpulan Berita</h2>

		<div class="special-services-1-grids">
			@foreach($berita as $key=>$value)
			<div class="col-md-3 special-services-1-grid">
				<div class="special-services-1-grid1">
					<img src="{{$value->gambar}}" alt=" " class="img-responsive" width="250px">

				</div>
				<h4>
					<!-- <a href="{{url('editnews/') }}">{{$value->nama}} </a> -->
					<?php
						echo '<a href="'.url('Detail/'.$value->id).'">'.$value->judul.'</a>';
						
					?>
				</h4>
				<p>{{ strlen($value->isi) > 100 ? substr($value->isi,0,100)  : $value->isi }}</p>
			</div>
			@endforeach
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
	
	
@endsection