@extends('layouts.front')
@section('content')
<div class="banner">
</div>
<!-- //banner -->
<div class="about w3agile-1">
	<div class="container">
		<h1 class="title">Detail Berita</h1>
		<div class="about-info">
			<div class="col-md-9 about-grids">
				<div class="about-row"></div>
				<h4><b> {{$berita->judul}} </b></h4>
				<h6><i>Ditulis Oleh : {{$berita->penulis}}, Pada {{$berita->created_at}}</i></h6>
				<img src="{{ asset($berita->gambar) }}" alt="" width="150px" />
				<p align="justify">
					{{$berita->isi}}
				</p>
			</div>
			<div class="col-md-3 about-grids">
				<div class="pince">
					<div class="pince-right">
						<h4> Visi </h4>
						<p>Terwujudnya lembaga pendidikan islam yang melahirkan generasi berilmu, beramal, dan berakhlakul karimah..</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<div class="container">
		<hr>
		<b> Komentar </b>
		<hr>
		<!-- Isi Komenta -->
		<div class="grid_3 grid_5">
		@foreach($comment as $key=>$value)
			<div class="well">
				{{$value->nama}} ,<i> Pada :{{$value->created_at}} </i><br>
				{{$value->isi}}
			</div>
		@endforeach
		</div>
		
		<!-- Tulis Komentar -->
		<form class="form-inline" method="post" action="{{url('addcoment')}}">
			{{ csrf_field() }}
			<input type="hidden" class="form-control" id="berita_id" required="" placeholder="Masukan Nama" name="berita_id" required="" value="{{$berita->id}}">

			<div class="form-group">
				<label for="email">Nama : </label>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="text" class="form-control" id="nama" required="" placeholder="Masukan Nama" name="nama" required="">
			</div>
			<br>
			<div class="form-group">
				<label for="pwd">Email :</label>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;<input type="text" class="form-control" id="email" placeholder="Masukan Email" name="email" value="-">
			</div>
			<br>
			<div class="form-group">
				<label for="pwd">No HP :</label>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="text" class="form-control" id="hp" placeholder="Masukan No HP/Telp" name="hp" value="-">
			</div>
			<br>
			<div class="form-group">
				<label for="pwd">Komentar :</label><br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<textarea name="isi" id="isi" class="form-control" required="" placeholder="Tulis Komentar" cols="25"></textarea>

			</div>
			<br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<!-- <input type="submit" class="hvr-rectangle-in" value="SEND MESSAGE"> -->
			<button type="submit" class="btn btn-default">Kirim</button>
			<!-- Komentar :<br> <textarea name="isi" id="isi" class="form-control" required=""></textarea>
		</div> -->
	</form>
</div>
</div>
@endsection