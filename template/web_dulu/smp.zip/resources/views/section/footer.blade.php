<div class="footer agileits">
				<div class="container">
					<div class="footer-bottom">
						<div class="col-md-4 footer-grids wow fadeInUp animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
							<h4>Information</h4>
							<p>SMP IT ( Islam Terpadu ) Darurrohmat merupakan SMP pertama dan satu-satunya yang berada di daerah Desa Parakan Kecamatan Leuwimunding, Kabupaten Majalengka. </p>
							</div>
							<div class="col-md-3 footer-grids footer-mdl w3agile wow fadeInUp animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
								<h4>Follow Us</h4>
								<div class="social">
									<ul>
										<li><a href="https://www.facebook.com/profile.php?id=100014082032865&fref=ts" class="facebook" target="blank"> </a></li>
										<li><a href="#" class="facebook twitter"> </a></li>
										<li><a href="#" class="facebook chrome"> </a></li>
										<li><a href="#" class="facebook in"> </a></li>

									</ul>		
								</div>
							</div>
							<div class="col-md-5 footer-grids agileinfo wow fadeInUp animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
								<h4>Contact Info</h4>
								<ul class="footer-address">
									<li><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Kampung sugih RT 04 RW 07 blok Jum'at Desa Parakan Kecamatan Leuwimunding Kabupaten Majalengka.</li>
									<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span><a href="mailto:smpit.darurrohmat@gmail.com">smpit.darurrohmat@gmail.com</a></li>
									<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> 081220933003 / 08132435329 </li>
								</ul>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="footer-copy w3 wow fadeInUp animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
							<p>© 2016 Heaped. All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
						</div>
					</div>
				</div>