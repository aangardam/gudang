<?php
use App\Models\slide;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
	$slide = slide::all()->where('status','=','Akrif');
    return view('front/index',compact('slide'));
});
Route::get('bantuan', function () {
    return view('front.zakat');
});
/*---------- FRONT --------------------*/
Route::get('about','FrontColtroller2@about');
Route::get('teachers','FrontColtroller2@teachers');

Route::get('contact','FrontColtroller2@contact');
Route::post('addcontact','FrontColtroller2@addcontact');

Route::get('news','FrontColtroller2@news');
Route::get('Detail/{id}','FrontColtroller2@detail');

Route::get('events','FrontColtroller2@events');
Route::get('Detail2/{id}','FrontColtroller2@detail2');
Route::get('gallery','FrontColtroller2@gallery');
Route::post('addcoment','FrontColtroller2@addcoment');
Route::post('addcoment2','FrontColtroller2@addcoment2');
Route::get('Downloads','FrontColtroller2@download');

/*---------- ADMIN --------------------*/

Auth::routes();
Route::group(['middleware' => 'auth'], function () {

Route::get('/home', 'HomeController@index');

Route::get('guru','GuruController@index');
Route::post('gurustore','GuruController@store');
Route::post('guruupdate','GuruController@update');
Route::get('gurudestroy/{id}','GuruController@destroy');

Route::get('album','AlbumController@index');
Route::post('albumstore','AlbumController@store');
Route::post('albumupdate','AlbumController@update');
Route::get('albumdestroy/{id}','AlbumController@destroy');

Route::get('galeri','GaleriController@index');
Route::post('galeristore','GaleriController@store');
Route::post('galeriupdate','GaleriController@update');

Route::resource('slide','SlieController');
Route::resource('berita','BeritaController');
Route::resource('download','downloadController');
Route::resource('comment','commentController');
Route::resource('comment2','commentController2');

Route::get('kegiatan','EventController@index');
Route::post('eventstore','EventController@store');
Route::get('evetsdestroy/{id}','EventController@destroy');
Route::post('eventupdate','EventController@update');

Route::get('kontak','ContackController@index');
Route::get('Contactsdestroy/{id}','ContackController@destroy');
Route::resource('user','UserController');

});